//
//  LiveViewController+PlaygroundLiveViewMessageHandler.swift
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//

import PlaygroundSupport
import UIKit
import SceneKit

extension LiveViewController: PlaygroundLiveViewMessageHandler {
        
    public func liveViewMessageConnectionClosed() {
        // Once the user taps "Stop", re-show the focus square
    }
    
    public func liveViewMessageConnectionOpened() {
        connectionOpened = true
        if (self.parentPlaced) {
            resetActorNode()
        }
        
        // Automatic VoiceOver to remind user to move iPad
        let axPlaneDetection = NSLocalizedString("Move the iPad around to detect planes.", comment: "Basic plane detection instructions")
        UIAccessibilityPostNotification(UIAccessibilityScreenChangedNotification, axPlaneDetection)
    }
    
    public func resetActorNode() {
        self.actor.node.transform = self.initialTransform
        self.rock.transform = self.initialRockTransform
        self.labDoor.simdTransform = simd_float4x4()
        self.gameState = self.initialGameState
        if lesson == 4 {
            self.iceCube.isHidden = false
        }
        countHack = 0
        passedLevel = false
        detectedObstacle = false
        wrongTempInput = false
        morseCodeResult = ""
        doorCodeResult = ""
        
        x = -1
        y = -2
        heading = 1
//        self.actor.setEyesColor(UIColor(0xcccccc))
    }
    
    fileprivate func completion(time: Double = 1.1) {
        DispatchQueue.main.asyncAfter(deadline: .now() + time, execute: {
            let liveViewController = PlaygroundPage.current.liveView as! PlaygroundLiveViewMessageHandler
            liveViewController.send(PlaygroundMessageFromLiveView.completion().playgroundValue)
        })
    }
    
    func checkWrongTempInput(index: Int, color: UIColor) -> Bool {
        switch index {
        case 0, 3:
            return color != UIColor.red
            
        case 1, 4:
//            fallthrough
//            case
            return color != UIColor.blue
            
        default:
            return false
        }
    }
    
//    - 0: -----
//    + 0: dash, dash, dash, dash, dash
//
//    - 1: .----
//    + 1: dot, dash, dash, dash, dash
//
//    - 2: ..---
//    + 2: dot, dot, dash, dash, dash
//
//    - 3: …--
//    + 3: dot, dot, dot, dash, dash
//
//    - 4: ….-
//    + 4: dot, dot, dot, dot, dash
//
//    - 5: …..
//    + 5: dot, dot, dot, dot, dot
//
//    - 6: -....
//    + 6: dash, dot, dot, dot, dot
//
//    - 7: --...
//    + 7: dash, dash, dot, dot, dot
//
//    - 8: ---..
//    + 8: dash, dash, dash, dot, dot
//
//    - 9: ----.
//    + 9: dash, dash, dash, dash, dot

    
    func stringFromMorseCode(_ code: String) -> String {
        switch code {
        case "-----":
            return "0"

        case ".----":
            return "1"

        case "..---":
            return "2"
            
        case "...--":
            return "3"
            
        case "....-":
            return "4"
            
        case ".....":
            return "5"
            
        case "-....":
            return "6"
            
        case "--...":
            return "7"
            
        case "---..":
            return "8"
            
        case "----.":
            return "9"
            
        default:
            return "?"
        }
    }
   
    public func receive(_ message: PlaygroundValue) {
        
        let numberStringArray = ["1", "6", "8"]
        
        let temperatureArray = ["100°C", "-100°C", "25°C", "60°C", "-10°C", "15°C", "10°C", ]
//        testCelsiusTemperature(100)
//        testCelsiusTemperature(-100)
//        testCelsiusTemperature(25)
//        testCelsiusTemperature(60)
//        testCelsiusTemperature(-10)
//        testCelsiusTemperature(15)
//        testCelsiusTemperature(10)
        
        guard let liveViewMessage = PlaygroundMessageToLiveView(playgroundValue: message) else { return }
        
        switch liveViewMessage {
            
        case .enableCameraVision:
            break
        case let .placeObjectOnPlane(object: object, plane: plane, position: position):
            
            guard let livePlane = self.planeWith(id: plane.id) else {
                log(message: "Unable to find plane with id: \(plane.id)")
                return
            }
            
            guard let virtualObject = self.getVirtualObject(for: object) else {
                log(message: "Failed to find or create \(object.name) object with id: \(object.id)")
                return
            }
            
            self.placeObject(object: virtualObject, on: livePlane, at: position)
            
        case let .setObjectColor(object: object, color: color):
            
            guard let shape = self.getVirtualObject(for: object) as? LiveShape else {
                log(message: "Failed to find or create shape with name: \(object.name) id: \(object.id)")
                return
            }
            
            shape.color = color
            
        case let .setObjectImage(object: object, image: image):
            
            guard let image = image else {
                log(message: "Nil image passed to live view")
                return
            }
            
            guard let shape = self.getVirtualObject(for: object) as? LiveShape else {
                log(message: "Failed to find or create shape with name: \(object.name) id: \(object.id)")
                return
            }
            
            shape.image = image
        case .setActorActions(let actor, let trigger, let actions):
            
//            if (trigger == .command) {
//                switch actions[0] {
//                case .turnRight:
//                    actor.turnRight()
//                case .turnLeft:
//                    actor.turnLeft()
//                case .moveForward:
//                    actor.moveForward()
//                case .pickUp:
//                    actor.carry()
//                case .dropOff:
//                    actor.putdown()
//                case .applaud:
//                    actor.applaud()
//                default:
//                    break
//                }
//
//            }
//            else {
            
                guard let virtualActor = self.getVirtualObject(for: actor) as? LiveActor else {
                    fatalError("Failed to find or create \(actor.name) object with id: \(actor.id) as Actor")
                }
                
                switch trigger {
                case .reactBehind:
                    virtualActor.behindActions += actions
                case .reactRight:
                    virtualActor.turnRightActions += actions
                case .reactLeft:
                    virtualActor.turnLeftActions += actions
                case .reactTooClose:
                    virtualActor.tooCloseActions += actions
                }
//            }
            
        case .announceObjectPlacement(let objects):
            announceObjectPlacement(objects: objects)
            
        case .sendAstrobotCommand(let command):
            switch command {
            case .turnLeft:
                gameState.turnLeft()
                actor.turnLeft(completion)
            
            case .turnRight:
                gameState.turnRight()
                actor.turnRight(completion)

            case .moveForward:
                if gameState.canMoveForward() {
                    gameState.moveForward()
                    actor.moveForward(completion)
                } else {
                    completion(time: 0.1)
                }

            case .applaud:
                actor.applaud(completion)
            
            case .pickUp:
                if gameState.canPickUpRock() {
                    self.passedLevel = true
                    
                    actor.pickup(completion)

                    // TODO: [Max] move this into the class that represent the rock
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.75, execute: {
                        SCNTransaction.begin()
                        SCNTransaction.animationDuration = 0.38
                        //            SCNTransaction.animationDuration = 0.4
                        SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
                        //            self.rock.transform = SCNMatrix4Mult(SCNMatrix4MakeTranslation(0, 1.5, 0), self.rock.transform)
                        self.rock.simdLocalTranslate(by: float3(-0.0305, 0, 0.077))
                        //            self.rock.simdLocalTranslate(by: float3(-0.03, 0, 0.075))
                        SCNTransaction.completionBlock = {
                            SCNTransaction.begin()
                            SCNTransaction.animationDuration = 0.02
                            SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
                            self.rock.simdLocalTranslate(by: float3(0.0005, 0, -0.002))
                            SCNTransaction.commit()
                        }
                        SCNTransaction.commit()
                    })
                } else {
                    completion(time: 0.1)
                }

            case .dropOff:
                if gameState.canPutDownRock() {
                    
                    actor.putdown(completion)

                    // TODO: [Max] move this into the class that represent the rock
                    SCNTransaction.begin()
                    SCNTransaction.animationDuration = 0.55
                    SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)
                    //        self.rock.transform = SCNMatrix4Mult(SCNMatrix4MakeTranslation(0, -1.5, 0), self.rock.transform)
                    self.rock.simdLocalTranslate(by: float3(0.03, 0, -0.075))
                    SCNTransaction.commit()
                } else {
                    completion(time: 0.1)
                }
            
            case .obstacleDetect:
                detectedObstacle = detectedObstacle || gameState.detectedObject()
                actor.shootIR(detected:gameState.detectedObject(), completion: completion)
            
            case .pickUpIceCube:
                if gameState.canPickUpIceCube() {
                    gameState.pickUpIceCube()
                    actor.pickupIceCube(completion)
                    iceCube.isHidden = true
                } else {
                    completion(time: 0.1)
                }
            
            case .dropOffIceCube:
                if gameState.canPutDownIceCube() {
                    passedLevel = true
                    gameState.putDownIceCube()
                    actor.putdownIceCube(completion)
                } else {
                    completion(time: 0.1)
                }
            
            case .redEyeColor:
                self.wrongTempInput = wrongTempInput || checkWrongTempInput(index: self.countHack, color: UIColor.red)
                
                self.flashText(temperatureArray[self.countHack], color: UIColor.black)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.25, execute: {
                    self.flashText("Too Hot", color: UIColor.red)
                    self.actor.flashEyeColor(UIColor.red, completion:self.completion)
                })

            case .blueEyeColor:
                self.wrongTempInput = wrongTempInput || checkWrongTempInput(index: self.countHack, color: UIColor.blue)
                
                self.flashText(temperatureArray[self.countHack], color: UIColor.black)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.25, execute: {
                    self.flashText("Too cold", color: UIColor.blue)
                    self.actor.flashEyeColor(UIColor.blue, completion:self.completion)
                })

            case .greenEyeColor:
                self.wrongTempInput = wrongTempInput || checkWrongTempInput(index: self.countHack, color: UIColor.green)
                
                self.flashText(temperatureArray[self.countHack], color: UIColor.black)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.25, execute: {
                    self.flashText("It's good", color: UIColor.green)
                    self.actor.flashEyeColor(UIColor.green, completion:self.completion)
                })

            case .dotEyeColor:
                morseCodeResult = morseCodeResult + "."
                countHack += 1
                if countHack % 5 == 0 {
                    let number = stringFromMorseCode(morseCodeResult)
                    doorCodeResult = doorCodeResult + number
                    countHack = 0
                    morseCodeResult = ""
                    
                    self.showDot()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.25, execute: {
                        self.flashText(number, color: UIColor.blue)
//                        self.countHack %= 15
                        self.completion(time: 1.25)
                    })
                } else {
                    self.showDot(completion)
                }
            
            case .barEyeColor:
                morseCodeResult = morseCodeResult + "-"
                countHack += 1
                if countHack % 5 == 0 {
                    let number = stringFromMorseCode(morseCodeResult)
                    doorCodeResult = doorCodeResult + number
                    countHack = 0
                    morseCodeResult = ""
                    
                    self.showDash()
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.25, execute: {
                        self.flashText(number, color: UIColor.blue)
//                        self.countHack %= 15
                        self.completion(time: 1.25)
                    })
                } else {
                    self.showDash(completion)
                }
            
            case .advanceHackCount:
                self.countHack = (self.countHack + 1) % temperatureArray.count
                self.completion(time: 0.25)
                
            case .shake:
                actor.putdown(completion)

            case .openDoor:
                self.openDoor(completion)

            }
            
        case .didRunCode:
            if planes.count > 0 {
                if let planeID = planes.first?.value.id {
                    send(
                        PlaygroundMessageFromLiveView.planeFound(plane: Plane(id: planeID)).playgroundValue
                    )
                }
            }
       case .finished:
            while(busyWithAction == true) {
                RunLoop.main.run(until: Date(timeIntervalSinceNow: 0.5))
            }
            
            // reset when finish executing
            self.countHack = 0
            
            var successString = "### Well done!\n\n[**Next Page**](@next)"
            let lastLessonSuccessString = "### Well done! Now the Mars base is ready for human to move in."
            var succeeded = false
            var hint = ""
            
            switch lesson {
            case 1:
                succeeded = passedLevel
                hint = "Try moving to the north side of the rock and lift it up from there."

            case 2:
                succeeded = detectedObstacle && gameState.robotPosition.x == 4 && gameState.robotPosition.z <= 0 && gameState.robotPosition.z >= -3
                hint = "Try using the IR sensor to detect the boulder, and go around it to navigate to the green highlighted region."

            case 4:
                succeeded = passedLevel
                hint = "Try navigating next to the ice cube before picking it up, and navigate next to the highlights region before dropping it off."
                
            case 5:
                succeeded = doorCodeResult == "168"
                if succeeded {
                    openDoor(nil)
                }
                hint = "Make sure you use the right sequence for each Morse code"
                
            case 6:
                succeeded = !wrongTempInput
                successString = lastLessonSuccessString
                hint = "Make sure you use blue color when it's below 0 degree Celsius to indicate it is too cold and red color when it's above 40 degree Celsius to indicate it's too hot."
                
            default:
                break
            }
            
            let results : AssessmentResults? = succeeded ? AssessmentResults.pass(message: successString) : AssessmentResults.fail(hints: [hint], solution: nil)
            
//            let results = self.assessmentInfo?.evaluate()
            switch results {
            case .pass(let message)?:
                guard let unwrappedMessage = message else {return}
                send(PlaygroundMessageFromLiveView.passed(message: unwrappedMessage).playgroundValue)
            case .fail(let hints, _)?:
                send(PlaygroundMessageFromLiveView.failed(message: hints[0]).playgroundValue)
            default:
                break
            }
            
        }
        
    }
}
