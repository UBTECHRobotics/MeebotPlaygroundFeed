//
//  AssessmentUtilities.swift
//  SupportingContent
//
//  Created by Liz Chaddock on 6/13/18.
//  Copyright © 2018 Apple Inc. All rights reserved.
//

import Foundation
import PlaygroundSupport

public typealias AssessmentResults = PlaygroundPage.AssessmentStatus

@objc(AssessmentInfo)
public class AssessmentInfo: NSObject {
    
    /// Defers the assessment of the world until `finishedEvaluating` message
    /// has been received.
    var evaluate: () -> AssessmentResults
    
    /// Set to indicate if the current run is a pass or fail.
    /// (Only set within the User process).
    var passedCriteria = false
    
    var hint = ""
    
    public init(evaluate: @escaping () -> AssessmentResults) {
        self.evaluate = evaluate
    }
}
