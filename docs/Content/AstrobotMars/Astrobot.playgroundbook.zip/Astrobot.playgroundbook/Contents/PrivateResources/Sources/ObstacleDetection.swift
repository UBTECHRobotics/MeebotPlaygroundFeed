var x: Int = -1
var y: Int = -2
var heading : Int = 1 // 0 is north, and clock wise increment
var obstacles = [(2, -2), (2, -1), (2, -3)]

//public func detectedObject(_ x: Int, _ y: Int) -> Bool {
//    var detected = false
//    for obstacle in obstacles {
//        switch heading {
//        case 0:
//            if (obstacle.0 == x && obstacle.1 == y - 1) {
//                detected = true
//            }
//        case 1:
//            if (obstacle.0 == x + 1 && obstacle.1 == y) {
//                detected = true
//            }
//        case 2:
//            if (obstacle.0 == x && obstacle.1 == y + 1) {
//                detected = true
//            }
//        case 3:
//            if (obstacle.0 == x - 1 && obstacle.1 == y) {
//                detected = true
//            }
//        default:
//            break
//        }
//    }
//    return detected
//}

public func moveForwardUpdate() {
    switch heading {
    case 0:
        y = y - 1
    case 1:
        x = x + 1
    case 2:
        y = y + 1
    case 3:
        x = x - 1
    default:
        break
    }
}

func turnLeftUpdate() {
    heading = (heading - 1 ) % 4
}

func turnRightUpdate() {
    heading = (heading + 1 ) % 4
}


