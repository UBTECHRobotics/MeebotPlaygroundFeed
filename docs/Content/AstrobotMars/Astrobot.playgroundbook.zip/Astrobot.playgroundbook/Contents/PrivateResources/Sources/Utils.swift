//
//  Utils.swift
//  ARKitImageRecognition
//
//  Created by WG on 2018/2/27.
//  Copyright © 2018年 Apple. All rights reserved.
//

import SceneKit

public struct SCNAssets {
    public static func rootNode(_ scnName:String) -> SCNNode? {
        if let scn = SCNScene(named: scnName + ".scn", inDirectory: "Models.scnassets/astrobot", options: [SCNSceneSource.LoadingOption.createNormalsIfAbsent:true, SCNSceneSource.LoadingOption.flattenScene:true]){
            return scn.rootNode.childNodes.first
        }
        return nil
    }
    
    public static func animationPlayers(_ scnName:String) -> [String: SCNAnimationPlayer] {
        var anims = [String: SCNAnimationPlayer]()
        if let scn = SCNScene(named: scnName + ".scn", inDirectory: "Models.scnassets/astrobot", options: [SCNSceneSource.LoadingOption.createNormalsIfAbsent:true, SCNSceneSource.LoadingOption.flattenScene:true]){
            scn.rootNode.enumerateChildNodes{n, _ in
                n.animationKeys.forEach{
                    if let p = n.animationPlayer(forKey: $0){
                        anims[$0] = p
                    }
                }
            }
        }
        return anims
    }
    
    public static func audioPlayer(_ name:String)->SCNAudioPlayer?{
        if let source = SCNAudioSource(named: "Sounds/" + name) {
            return SCNAudioPlayer(source: source)
        }
        return nil
    }
    public static func particle(_ scnName:String)->SCNParticleSystem?{
        return SCNParticleSystem(named: "dust", inDirectory: "Scenes.scnassets")
    }
}

extension UIColor{
    public convenience init(_ rgb:Int){
        self.init(red: CGFloat(rgb >> 16) / 256.0, green: CGFloat(rgb >> 8 & 0xff) / 256.0, blue: CGFloat(rgb & 0xff) / 256.0, alpha: 1)
    }
    public static func ==(left:UIColor, right:UIColor) -> Bool {
        var arr1 = [UnsafeMutablePointer<CGFloat>]()
        var arr2 = [UnsafeMutablePointer<CGFloat>]()
        (0..<3).forEach{_ in
            arr1.append(UnsafeMutablePointer<CGFloat>.allocate(capacity: 1))
            arr2.append(UnsafeMutablePointer<CGFloat>.allocate(capacity: 1))
        }
        defer{
            arr1.forEach{
                $0.deallocate(capacity: 1)
            }
            arr2.forEach{
                $0.deallocate(capacity: 1)
            }
        }
        left.getRed(arr1[0], green: arr1[1], blue: arr1[2], alpha: nil)
        right.getRed(arr2[0], green: arr2[1], blue: arr2[2], alpha: nil)
        for i in 0..<3{
            if fabsf(Float(arr1[i].pointee - arr2[i].pointee)) > 0.01{
                return false
            }
        }
        return true
    }
}
