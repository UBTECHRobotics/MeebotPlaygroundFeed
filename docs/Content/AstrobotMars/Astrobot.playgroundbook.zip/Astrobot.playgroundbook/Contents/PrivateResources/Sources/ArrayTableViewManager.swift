//
//  ArrayTableViewManager.swift
//  LiveView
//
//  Created by Max Mai on 6/7/18.
//  Copyright © 2018 Liz Chaddock. All rights reserved.
//

import Foundation
import UIKit


typealias TableCellOnSelect = (Int) -> Void

public struct TableItem {
    var title : String
    var onSelect : TableCellOnSelect
}

public class ArrayTableViewManager : NSObject, UITableViewDataSource, UITableViewDelegate {
    
    public init(arrayItems: [TableItem]) {
        self.arrayItems = arrayItems
    }

    private let arrayItems : [TableItem]
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrayItems.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) 
        cell.textLabel?.text = arrayItems[indexPath.item].title
        return cell
    }
    
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        arrayItems[indexPath.item].onSelect(indexPath.item)
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
}
