//
//  GameState.swift
//  LiveView
//
//  Created by Max Mai on 9/25/18.
//  Copyright © 2018 Liz Chaddock. All rights reserved.
//

import Foundation


enum Facing : Int {
    case north
    case east
    case south
    case west
    
    func turnLeft() -> Facing {
        return Facing(rawValue: (self.rawValue - 1 + 4) % 4)!
    }
    
    func turnRight() -> Facing {
        return Facing(rawValue: (self.rawValue + 1 + 4) % 4)!
    }
}

enum LocationType {
    case unblocked
    case boulder
    case solarPanel
}

enum ObjectCarriedByAstrobot {
    case none
    case iceCube
    case rock
    case solarPanel
}

struct PositionAndOrientation {
    var facing : Facing = .south
    var x : Int = 0
    var z : Int = 0
    
    func facingPosition() -> PositionAndOrientation {
        var newPosition = self
        switch facing {
        case .north:
            newPosition.z -= 1
            break
        case .east:
            newPosition.x += 1
            break
        case .south:
            newPosition.z += 1
            break
        case .west:
            newPosition.x -= 1
            break
        }
        
        return newPosition
    }
}

func ==(lhs: PositionAndOrientation, rhs: PositionAndOrientation) -> Bool{
    return lhs.x == rhs.x && lhs.z == rhs.z
}

struct GameState {
    var robotPosition : PositionAndOrientation
    var rockPositon: PositionAndOrientation
    var boulderPositions : [PositionAndOrientation]
    var iceCubePosition : PositionAndOrientation
    var solarPanelPositions : [PositionAndOrientation]
    var objectCarriedByAstrobot : ObjectCarriedByAstrobot
    var iceCubeDestination : PositionAndOrientation
    
    var xPositionRange : ClosedRange<Int>
    var zPositionRange : ClosedRange<Int>
    
    var rockWasLifted = false
    
    mutating func turnLeft() {
        if objectCarriedByAstrobot != .rock {
            self.robotPosition.facing = robotPosition.facing.turnLeft()
        }
    }

    mutating func turnRight()  {
        if objectCarriedByAstrobot != .rock {
            self.robotPosition.facing = robotPosition.facing.turnRight()
        }
    }
    
    func canMoveForward() -> Bool {
        return !detectedObject() && isPositionWithinBounds(position: robotPosition.facingPosition()) && objectCarriedByAstrobot != .rock
    }
    
    mutating func moveForward() {
        if canMoveForward() {
            self.robotPosition = robotPosition.facingPosition()
        }
    }
    
    func canPickUpRock() -> Bool {
        return self.rockPositon == self.robotPosition.facingPosition() && self.robotPosition.facing == .south && objectCarriedByAstrobot == .none
    }
    
    mutating func pickUpRock() {
        if canPickUpRock() {
            objectCarriedByAstrobot = .rock
        }
    }
    
    func canPutDownRock() -> Bool {
        return objectCarriedByAstrobot == .rock
    }
    
    mutating func putDownRock() {
        objectCarriedByAstrobot = .none
    }
    
    func canPickUpIceCube() -> Bool {
        return self.iceCubePosition == self.robotPosition.facingPosition() && objectCarriedByAstrobot == .none
    }
    
    mutating func pickUpIceCube() {
        if canPickUpIceCube() {
            objectCarriedByAstrobot = .iceCube
        }
    }
    
    func canPutDownIceCube() -> Bool {
        return self.iceCubeDestination == self.robotPosition.facingPosition() && objectCarriedByAstrobot == .iceCube
    }
    
    mutating func putDownIceCube() {
        if (canPutDownIceCube()) {
            objectCarriedByAstrobot = .none
        }
    }
    
    func canPickUpSolarPanel() -> Bool {
        return self.solarPanelPositions[0] == self.robotPosition.facingPosition()
    }
    
    mutating func pickUpSolarPanel() {
        if canPickUpSolarPanel() {
            objectCarriedByAstrobot = .solarPanel
        }
    }
    
    mutating func putDownSolarPanel() {
        objectCarriedByAstrobot = .none
    }
    
    func detectedObject() -> Bool {
        var detected = false
        
        let detectionPosition = self.robotPosition.facingPosition()
        
        var obstaclePositions = self.boulderPositions
        obstaclePositions.append(self.rockPositon)
        obstaclePositions.append(contentsOf: self.solarPanelPositions)
        obstaclePositions.append(self.iceCubePosition)
        
        for obstaclePosition in obstaclePositions {
            if detectionPosition == obstaclePosition {
                detected = true
                break
            }
        }
        
        return detected
    }
    
    func isPositionWithinBounds(position: PositionAndOrientation) -> Bool {
        return xPositionRange.contains(position.x) && zPositionRange.contains(position.z)
    }

}

//func canPickUpIceCube(gameState: GameState) -> Bool {
//    return gameState.iceCubePosition == gameState.robotPosition.facingPosition()
//}
//
//func turnLeft(gameState: GameState) -> GameState {
//    var newGameState = gameState
//    newGameState.robotPosition.facing = gameState.robotPosition.facing.turnLeft()
//    return newGameState
//}
//
//func turnRight(gameState: GameState) -> GameState  {
//    var newGameState = gameState
//    newGameState.robotPosition.facing = gameState.robotPosition.facing.turnRight()
//    return newGameState
//}
//
//func moveForward(gameState: GameState) -> GameState  {
//    var newGameState = gameState
//    newGameState.robotPosition = gameState.robotPosition.facingPosition()
//    return newGameState
//}




