import Foundation
import PlaygroundSupport

var busyWithAction = false

public func moveForward(Distance: Int) {
    var i : Int = 0
    while (i < Distance) {
        sendAstrobotCommandToLiveView(command:AstrobotCommand.moveForward)
        i += 1
        
        moveForwardUpdate()
    }
}

public func turnLeft() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.turnLeft)
    
    turnLeftUpdate()
}

public func turnRight() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.turnRight)
    
    turnRightUpdate()
}

public func applaud() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.applaud)
    
}

public func pickUp() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.pickUp)
}

public func dropOff() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.dropOff)
}

public func pickUpIceCube() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.pickUpIceCube)
}

public func dropOffIceCube() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.dropOffIceCube)
}

public func setRedEyeColor() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.redEyeColor)
}

public func setBlueEyeColor() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.blueEyeColor)
}

public func setGreenEyeColor() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.greenEyeColor)
}

public func showDot() {
    setDotEyeColor()
}

public func setDotEyeColor() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.dotEyeColor)
}

public func showDash() {
    setBarEyeColor()
}

public func setBarEyeColor() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.barEyeColor)
}

public func openDoor() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.openDoor)
}

public func shake() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.shake)
}

public func prepareForNextTemperature() {
    sendAstrobotCommandToLiveView(command:AstrobotCommand.advanceHackCount)
}

public func hasObstacle()->Bool{
    sendAstrobotCommandToLiveView(command:.obstacleDetect)
    var detected = false
    for obstacle in obstacles {
        switch heading {
        case 0:
            if (obstacle.0 == x && obstacle.1 == y - 1) {
                detected = true
            }
        case 1:
            if (obstacle.0 == x + 1 && obstacle.1 == y) {
                detected = true
            }
        case 2:
            if (obstacle.0 == x && obstacle.1 == y + 1) {
                detected = true
            }
        case 3:
            if (obstacle.0 == x - 1 && obstacle.1 == y) {
                detected = true
            }
        default:
            break
        }
    }

    return detected
}

private func sendAstrobotCommandToLiveView(command: AstrobotCommand) {
    guard let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy else { return }
    
    while(busyWithAction == true) {
        RunLoop.main.run(until: Date(timeIntervalSinceNow: 0.5))
    }
    
    busyWithAction = true

    proxy.send(
        PlaygroundMessageToLiveView.sendAstrobotCommand(command: command).playgroundValue
    )

}

