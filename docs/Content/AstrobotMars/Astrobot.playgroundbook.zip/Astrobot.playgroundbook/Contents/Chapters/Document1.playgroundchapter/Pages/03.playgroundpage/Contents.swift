//#-hidden-code
//
//  Contents.swift
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal:**  Turn on AstroBot’s LED lights and then fix the solar panels powering the base
 
 Bad news! The dust from the sandstorm now covers most of the solar panels. Fortunately, the panels are not damaged. Program a function to remove the dust from a single solar panel by lifting up the panel and shaking it gently. Repeat this step with each solar panel.
 
 **HINT:**  Use AstroBot’s LED lights to see the solar panels when it gets dark.
 1. Turn on LED lights so AstroBot can see at night
 2. Create a function for restore a single solar panel by lifting up and releasing a solar panel
 3. Navigate to each solar panel and then use the function to restore them
 */

//#-hidden-code
import PlaygroundSupport
let manager = ContentsManager.shared()
manager.page.needsIndefiniteExecution = true
let proxy = manager.page.liveView as? PlaygroundRemoteLiveViewProxy

proxy?.send(
    PlaygroundMessageToLiveView.didRunCode.playgroundValue
)

typealias Character = Actor
typealias Action = ActorAction

//TODO trigger animation to start here

//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, page, proxy, Listener, listener, planes, placedObjectsCount, planeCount, CharacterName, blu, hopper, expert, Character, let, plane, character, DetectionListener, sendAstrobotCommandToLiveView(command:), detectedPlane(plane:))
//#-code-completion(identifier, show, moveForward(Distance:), turnRight(), turnLeft(), hasObstacle())
//#-code-completion(identifier, show, while, for, if, var, let, ., (, ), (),,)
manager.waitForPlane()
//#-end-hidden-code

//#-editable-code
turnLeft()
moveForward(Distance:1)
turnRight()
moveForward(Distance:1)
pickUp()
dropOff()
applaud()
//#-end-editable-code

//#-hidden-code
//#-end-hidden-code

//#-hidden-code
proxy?.send(
    PlaygroundMessageToLiveView.finished.playgroundValue
)
// PlaygroundPage.current.finishExecution()
//#-end-hidden-code
