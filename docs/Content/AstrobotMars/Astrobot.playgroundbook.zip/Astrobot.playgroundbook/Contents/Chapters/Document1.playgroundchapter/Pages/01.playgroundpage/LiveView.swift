//
//  LiveView.swift
//
//  Copyright © 2016,2017 Apple Inc. All rights reserved.
//

import PlaygroundSupport
import UIKit

let page = PlaygroundPage.current
let liveViewController: LiveViewController = LiveViewController.makeFromStoryboard()
liveViewController.assessmentInfo = AssessmentInfo(evaluate: { return .pass(message: "Good job!")})
liveViewController.lesson = 1
//liveViewController.isCommandListVisible = false
page.liveView = liveViewController

