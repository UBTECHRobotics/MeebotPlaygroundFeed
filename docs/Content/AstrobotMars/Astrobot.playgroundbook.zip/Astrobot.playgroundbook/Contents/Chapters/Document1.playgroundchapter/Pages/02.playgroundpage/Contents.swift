//#-hidden-code
//
//  Contents.swift
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Send AstroBot to the green-colored region using the robot’s [IR sensor](glossary://IR%20sensor) to avoid obstacles such as boulders.
 
 AstroBot has arrived at the base and must travel to the solar panels to fix them. Unfortunately, there are some large boulders in its way.  Help AstroBot get to the base while avoiding these massive boulders using the IR sensor on AstroBot. Be careful — the [Martian wind](glossary://Martian%20wind) changes frequently, so boulders often move to new positions.
 
 1. Use the provided obstacle detection feature to check if there are any obstacles in front of Astrobot.
 
 2. Since the IR sensor only detects obstacles in front of AstroBot, you will need to turn AstroBot multiple times to re-detect obstacles.

 */

//#-hidden-code
import PlaygroundSupport
let manager = ContentsManager.shared()
manager.page.needsIndefiniteExecution = true
let proxy = manager.page.liveView as? PlaygroundRemoteLiveViewProxy

proxy?.send(
    PlaygroundMessageToLiveView.didRunCode.playgroundValue
)

typealias Character = Actor
typealias Action = ActorAction

//TODO trigger animation to start here

//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, page, proxy, Listener, listener, planes, placedObjectsCount, planeCount, CharacterName, blu, hopper, expert, Character, let, plane, character, DetectionListener, sendAstrobotCommandToLiveView(command:), detectedPlane(plane:))
//#-code-completion(identifier, show, moveForward(Distance:), turnRight(), turnLeft(), hasObstacle())
//#-code-completion(identifier, show, while, for, if, var, let, ., (, ), (),,)
manager.waitForPlane()
//#-end-hidden-code
//#-editable-code


//#-end-editable-code

//#-hidden-code
//while (!hasObstacle()){
//    moveForward(Distance:1)
//}
//turnRight()
//moveForward(Distance:2)
//turnLeft()
//moveForward(Distance:3)
//#-end-hidden-code

//#-hidden-code
//applaud()
proxy?.send(
    PlaygroundMessageToLiveView.finished.playgroundValue
)
//#-end-hidden-code
