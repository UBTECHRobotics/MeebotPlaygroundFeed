//#-hidden-code
//
//  Contents.swift
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal:** Locate ice on Mars and return some to the base
 
 The process of changing ice or water into oxygen and hydrogen is an example of [electrolysis](glossary://Electrolysis). Search the surface of Mars for large cubes of ice, so you can begin this chemical process using machines back at the base. Avoid the boulders using the algorithm you developed in the last chapter. After you reach the ice cubes, lift them and return them to the base.
 
 1. Use the obstacle avoidance algorithm you developed in last chapter to reach the ice cubes
 2. Lift them and bring them back to the base
 */

//#-hidden-code
import PlaygroundSupport
let manager = ContentsManager.shared()
manager.page.needsIndefiniteExecution = true
let proxy = manager.page.liveView as? PlaygroundRemoteLiveViewProxy

proxy?.send(
    PlaygroundMessageToLiveView.didRunCode.playgroundValue
)

typealias Character = Actor
typealias Action = ActorAction

//TODO trigger animation to start here

//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, page, proxy, Listener, listener, planes, placedObjectsCount, planeCount, CharacterName, blu, hopper, expert, Character, let, plane, character, DetectionListener, sendAstrobotCommandToLiveView(command:), detectedPlane(plane:))
//#-code-completion(identifier, show, moveForward(Distance:), turnRight(), turnLeft(), pickUpIceCube(), dropOffIceCube())
//#-code-completion(identifier, show, while, for, if, var, let, ., (, ), (),,)
manager.waitForPlane()
//#-end-hidden-code
//#-editable-code


//#-end-editable-code

//#-hidden-code
//turnRight()
//moveForward(Distance:2)
//turnLeft()
//moveForward(Distance:2)
//turnLeft()
//moveForward(Distance:2)
//turnRight()
//pickUpIceCube()
//turnRight()
//moveForward(Distance:2)
//turnRight()
//moveForward(Distance:2)
//turnRight()
//moveForward(Distance:2)
//turnLeft()
//dropOffIceCube()
//#-end-hidden-code

//#-hidden-code
proxy?.send(
    PlaygroundMessageToLiveView.finished.playgroundValue
)
//PlaygroundPage.current.finishExecution()
//#-end-hidden-code
