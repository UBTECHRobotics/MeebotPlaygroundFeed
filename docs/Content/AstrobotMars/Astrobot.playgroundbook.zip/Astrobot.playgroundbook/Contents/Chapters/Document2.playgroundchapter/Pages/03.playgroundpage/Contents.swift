//#-hidden-code
//
//  Contents.swift
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal:** Inform the base computer whether the temperature is too high or too low inside the base using AstroBot’s LED lights.
 
 Compared to Earth’s surface temperature, Mars is generally cold. The average Mars surface temperature is around −81°F or −63°C. The base computer must learn what temperature range to set the base, so humans can live there in the future. Have AstroBot read the thermometer and teach the computer whether it’s too hot or too cold by showing different color in the LED lights on AstroBot.
 
1. Show blue color LED when it’s too cold, red color when it’s too hot; green when it’s perfect; orange when it’s warm, and purple when it’s cool.
 
2. Let’s make sure it’s blue when it’s below 0 °C, and red when it’s above 40 °C. Decide on the range for the color on your own preferences. Please make sure they are consistent so that our AI can learn it correctly.

 */

//#-hidden-code
import PlaygroundSupport
let manager = ContentsManager.shared()
manager.page.needsIndefiniteExecution = true
let proxy = manager.page.liveView as? PlaygroundRemoteLiveViewProxy

proxy?.send(
    PlaygroundMessageToLiveView.didRunCode.playgroundValue
)

typealias Character = Actor
typealias Action = ActorAction

//TODO trigger animation to start here

//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, page, proxy, Listener, listener, planes, placedObjectsCount, planeCount, CharacterName, blu, hopper, expert, Character, let, plane, character, DetectionListener, sendAstrobotCommandToLiveView(command:), detectedPlane(plane:))
//#-code-completion(identifier, show, setRedEyeColor(), setBlueEyeColor(), setGreenEyeColor())
//#-code-completion(identifier, show, while, for, if, var, let, ., (, ), (),,)
manager.waitForPlane()
//#-end-hidden-code
public func testCelsiusTemperature(_ temperature:Int){
    //#-editable-code
    if temperature > 40 {
        
    }
    if temperature < 0 {
        
    }

    //#-end-editable-code
    //#-hidden-code
    prepareForNextTemperature()
    //#-end-hidden-code
}

testCelsiusTemperature(100)
testCelsiusTemperature(-100)
testCelsiusTemperature(25)
testCelsiusTemperature(60)
testCelsiusTemperature(-10)
testCelsiusTemperature(15)
testCelsiusTemperature(10)

//#-hidden-code
//if temperature > 40 {
//    setRedEyeColor()
//}
//if temperature < 0 {
//    setBlueEyeColor()
//}
//if temperature >= 0 && temperature <= 40 {
//    setGreenEyeColor()
//}
//#-end-hidden-code

//#-hidden-code

proxy?.send(
    PlaygroundMessageToLiveView.finished.playgroundValue
)
//PlaygroundPage.current.finishExecution()
//#-end-hidden-code
