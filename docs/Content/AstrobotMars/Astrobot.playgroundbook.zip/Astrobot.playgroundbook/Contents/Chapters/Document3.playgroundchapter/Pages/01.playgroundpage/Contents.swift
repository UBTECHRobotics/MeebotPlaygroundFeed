//#-hidden-code
//
//  Contents.swift
//
//  Copyright © 2017 Apple Inc. All rights reserved.
//
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal:** Refuel the spaceship without wasting more than 10% of the existing gas.
 
 It’s time to pump fuel into the rocket boosters! Using the formula you just learned, you must decide if the amount of rocket fuel AstroBot has collected is enough to power the rocket. How much more fuel should the robot pump to carry the spaceship back to Earth?
 
 Remember: Don’t bring too much or you will waste fuel. To complete the mission, don’t waste more than 10% of the fuel we have collected.
 
 1. Implement the function that calculates whether the current fuel level is sufficient
 2. Command AstroBot to keep pumping hydrogen fuels from the wells to the spaceship while it’s not sufficient
 3. Make sure there’s enough fuel without wasting more than 10% of fuels.
 */

//#-hidden-code
import PlaygroundSupport
let manager = ContentsManager.shared()
manager.page.needsIndefiniteExecution = true
let proxy = manager.page.liveView as? PlaygroundRemoteLiveViewProxy

proxy?.send(
    PlaygroundMessageToLiveView.didRunCode.playgroundValue
)

typealias Character = Actor
typealias Action = ActorAction

//TODO trigger animation to start here

//#-code-completion(everything, hide)
//#-code-completion(identifier, show, CharacterName, meebot, astrobot, expert, .)
//let character = Character(name: CharacterName.astrobot)
//#-code-completion(currentmodule, show)
//#-code-completion(everything, hide)
//#-code-completion(identifier, hide, page, proxy, Listener, listener, planes, placedObjectsCount, planeCount, CharacterName, blu, hopper, expert, Character, let, plane, character, DetectionListener, sendAstrobotCommandToLiveView(command:), detectedPlane(plane:))
//#-code-completion(identifier, show, jump, turnRight(), turnLeft(), Action)
//#-code-completion(identifier, show, moveForward(Distance:), turnRight(), turnLeft(), applaud(), pickUp(), dropOff())
//#-code-completion(identifier, show, var, let, ., (, ), (),,)

manager.waitForPlane()

//#-end-hidden-code

    //#-editable-code
        turnLeft()
        moveForward(Distance:1)
        turnRight()
        moveForward(Distance:1)
        pickUp()
        dropOff()
        applaud()
    //#-end-editable-code

//#-hidden-code
PlaygroundPage.current.finishExecution()
//#-end-hidden-code
