//
//  Assessment.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

let tip = NSLocalizedString("Create another dance sequence after the while loop.", comment:"Success message")

let success = NSLocalizedString("### Well done!\nYou know how to dance with the music.\n\n[**Next Page**](@next)", comment:"Success message")

public func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    let checker = ContentsChecker(contents: PlaygroundPage.current.text)
    guard let state_while = checker.loopNodes.first else {
        return .fail(hints: [tip], solution: nil)
    }
    if checker.calledFunctions.count - state_while.body.count == 0 {
        return .fail(hints: [tip], solution: nil)
    }
    return .pass(message: success)
}
