//
//  CheckedCell.swift
//  LiveView
//
//  Created by Liz Chaddock on 6/29/17.
//  Copyright © 2017 Liz Chaddock. All rights reserved.
//

import Foundation
import UIKit
#if APP
    import DTModelStorage
#endif

class CheckedCell : UITableViewCell, ModelTransfer {
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .subtitle, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func update(with model: CheckedCellModel) {
        self.textLabel?.text = model.title
        self.detailTextLabel?.text = model.subtitle
        
        if model.checked {
            self.accessoryType = .checkmark
            self.textLabel?.textColor = UIColor.orange
            self.detailTextLabel?.textColor = UIColor.orange
        }
        else {
            self.accessoryType = .none
            self.textLabel?.textColor = UIColor.black
            self.detailTextLabel?.textColor = UIColor.gray
        }
    }
}
