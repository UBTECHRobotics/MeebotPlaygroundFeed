//
//  AudioMenuController.swift
//  PlaygroundScene
//
//  Created by Chao He on 2017/2/28.
//  Copyright © 2017年 UBTech Inc. All rights reserved.
//

import UIKit
import MediaPlayer
#if APP
import DTTableViewManager
#endif

protocol AudioMenuControllerDelegate {
    func enableAudioMenuSelect(_ isEnabled: Bool)
    func playSongAt(index: Int)
}

protocol AudioMenuMusicPickerDelegate {
    func mediaPickerDidPickMediaItem(mediaItemCollection:MPMediaItemCollection)
}

class AudioMenuController: UITableViewController {
    
    // MARK: Properties
    var menuMusicPickerDelegate: AudioMenuMusicPickerDelegate?
    var audioMenuDataSource: AudioMenuDataSource?
    var actionHandler: AudioMenuActionHandler?
    
    // MARK: Initializtion
    required init?(coder aDecoder: NSCoder) {
        self.audioMenuDataSource = nil
        super.init(coder: aDecoder)
    }
    
    override init(style: UITableViewStyle) {
        super.init(style: .grouped)
    }
    
    init(songArray:[String], menuDelegate:AudioMenuControllerDelegate){
        super.init(style: .grouped)
        let actionHandler = AudioMenuActionHandler(with: self, menuDelegate: menuDelegate)
        self.audioMenuDataSource = AudioMenuDataSource(with: songArray, actionHandler:actionHandler, tableView: self.tableView)
        self.actionHandler = actionHandler
        self.actionHandler?.dataSource = self.audioMenuDataSource
    }
    
    // MARK: View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = NSLocalizedString("Music", comment: "title of popover")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let navigation = navigationController {
            navigation.preferredContentSize = CGSize(width: 250, height: tableView.contentSize.height)
        }
        
        guard let musicMenuOpen = audioMenuDataSource?.playMusicEnabled else {
            return
        }
        if musicMenuOpen {
            self.audioMenuDataSource?.setTableViewCellDefaultSelected()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if let navigationController = self.navigationController {
            navigationController.preferredContentSize = CGSize(width: 250, height: tableView.contentSize.height)
        }
    }
    
    // Update to the lastest selected cell
    func updateSelectedCell(index: Int) {
        // Persist the current select index
        Persisted.backgroudAudioSelectedIndex = index
        self.audioMenuDataSource?.setTableViewCellSelected(index: index)
    }
}

// MARK: MPMediaPickerControllerDelegate

extension AudioMenuController: MPMediaPickerControllerDelegate {
    
    func mediaPicker(_ mediaPicker: MPMediaPickerController, didPickMediaItems mediaItemCollection: MPMediaItemCollection) {
        assert(mediaItemCollection.count > 0)
        audioMenuDataSource?.updateWith(mediaItem:mediaItemCollection.items[0])
        
        self.menuMusicPickerDelegate?.mediaPickerDidPickMediaItem(mediaItemCollection: mediaItemCollection)
        self.dismiss(animated: true, completion: nil)
    }
    
    func mediaPickerDidCancel(_ mediaPicker: MPMediaPickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}
