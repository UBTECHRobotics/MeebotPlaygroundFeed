//
//  SwitchCell.swift
//  LiveView
//
//  Created by Liz Chaddock on 6/28/17.
//  Copyright © 2017 Liz Chaddock. All rights reserved.
//

import Foundation
import UIKit
#if APP
    import DTModelStorage
#endif

fileprivate let kTableViewHeaderHeight = 40

class SwitchCell : UITableViewCell, ModelTransfer {
    var switchControl : UISwitch
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        self.switchControl = UISwitch(frame: CGRect(x: 180, y: 5, width: 70, height: kTableViewHeaderHeight))
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.accessoryView = switchControl
        self.selectionStyle = .none
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func update(with model: SwitchCellModel) {
        self.textLabel?.text = model.text
        switchControl.isOn = model.isOn
        switchControl.addTarget(model.target, action: model.selector, for: .valueChanged)
    }
}
