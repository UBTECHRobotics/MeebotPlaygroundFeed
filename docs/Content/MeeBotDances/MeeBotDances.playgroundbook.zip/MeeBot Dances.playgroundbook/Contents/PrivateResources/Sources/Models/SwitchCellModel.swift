//
//  SwitchCellModel.swift
//  LiveView
//
//  Created by Liz Chaddock on 6/28/17.
//  Copyright © 2017 Liz Chaddock. All rights reserved.
//

import Foundation

class SwitchCellModel : NSObject {
    var text : String
    var isOn : Bool
    var selector : Selector
    var target : Any
    
    init(text: String, isOn: Bool, selector: Selector, target: Any) {
        self.text = text
        self.isOn = isOn
        self.selector = selector
        self.target = target
    }
}
