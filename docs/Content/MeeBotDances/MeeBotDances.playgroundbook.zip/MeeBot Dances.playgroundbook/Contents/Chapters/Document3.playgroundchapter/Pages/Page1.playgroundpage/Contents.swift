//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
*/
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Show time.
 
 Congratulations! You have learned how to program MeeBot to dance with code. It’s time for a final performance for your friends and family.
 
 Below, you can use the provided code to get you started or create a brand new routine. You can also choose your own song! Tap the music menu and select a song from your music library. Find the BPM with a quick internet search and input it below. You could also set a timer for a minute and count beats as you listen to your song.
 
 You can record a movie of the performance to share with others by using the 'record movie' option in the Tools menu.
 
 Enjoy!
*/
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward(), raiseHands(), bend(), happy(), split(), skip(), twist(), stepAndShake(), bendAndTwist(), crazyDance(), shake(), wave(), swagger(), crazyDance(), moveToLeft(beats:), moveToRight(beats:), moveForward(beats:), moveBackward(beats:), raiseHands(beats:), bend(beats:), happy(beats:), split(beats:), skip(beats:), twist(beats:), stepAndShake(beats:), bendAndTwist(beats:), crazyDance(beats:), shake(beats:), wave(beats:), swagger(beats:), moveBody(moves:), moveBody(beats:moves:), moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:), moveLeftArm(angle:beats:), moveRightArm(angle:beats:), moveLeftLeg(angle:beats:), moveRightLeg(angle:beats:), moveLeftFoot(angle:beats:), moveRightFoot(angle:beats:), crazyDance(beats:), isPlaying(song:), setBpmOfMySong(bpm:))
//#-code-completion(identifier, show, musicIntro, musicBitBitLoop)
//#-code-completion(keyword, show, for, func, if, var, while)
//#-editable-code Tap to enter code
setBpmOfMySong(bpm:<#T##BPM##UInt#>)

while isPlaying(song:musicIntro) {
    bend(beats:2)
    stepAndShake(beats:1)
    skip(beats:2)
    swagger(beats:2)
}

crazyDance()

for _ in 0..<4 {
    moveBody(beats:1) {
        moveLeftArm(angle:80)
        moveRightFoot(angle:80)
    }
    moveBody(beats:1) {
        moveLeftArm(angle:0)
        moveRightFoot(angle:0)
    }
    moveBody(beats:1) {
        moveRightArm(angle:-80)
        moveLeftFoot(angle:-80)
    }
    moveBody(beats:1) {
        moveRightArm(angle:0)
        moveLeftFoot(angle:0)
    }
    bendAndTwist(beats:2)
    moveBody(beats:1) {
        moveLeftArm(angle:0)
        moveLeftFoot(angle:0)
        moveRightArm(angle:0)
        moveRightFoot(angle:0)
    }
}
//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code

