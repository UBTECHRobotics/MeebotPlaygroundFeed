//
//  Assessment.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

public func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    return .pass(message: "")
}
