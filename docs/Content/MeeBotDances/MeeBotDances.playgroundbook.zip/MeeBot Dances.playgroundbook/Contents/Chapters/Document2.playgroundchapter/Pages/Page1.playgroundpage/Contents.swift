//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
//#-hidden-code
import SceneKit
import PlaygroundSupport
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Create 2 dance routines for MeeBot using different music for each.
 
 MeeBot should dance differently to different music. Conditional code can help MeeBot know how fast or slow to dance. Let’s use [if](glossary://if%20block) and [else if](glossary://else%20if%20block) to help MeeBot adjust to different music.
 
 A [beat](glossary://beat) is a pulse of time. If you speed up or slow down the music, you're changing the [tempo](glossary://tempo) or [BPM](glossary://BPM).
 
 The music setting in the Live View has two songs. Intro is a slow song with a BPM of 60 and Bit Bit Loop is a fast song with a BPM of 100. When the music is playing, the BPM will display in the top-left corner. Create different dance moves for both songs and use the if statement to check whether `BPMofCurrentMusic` is equal to 60(slow), or 120(fast).
 
 1. Create 2 different dance routines.
 2. Call the dance routine functions separately under if and else statements.
 3. Tap **Run My Code** to see how MeeBot responds to your code.
 4. Switch back and forth between the two songs and see how MeeBot dances.
 */
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward(), raiseHands(), bend(), happy(), split(), skip(), twist(), stepAndShake(), bendAndTwist(), crazyDance(), shake(), wave(), swagger(), moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:))
if BPMofCurrentMusic == 60 {
    //#-editable-code Tap to enter code
    //#-end-editable-code
}
else {
    //#-editable-code Tap to enter code
    //#-end-editable-code
}
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code


