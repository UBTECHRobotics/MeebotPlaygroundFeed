//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Use a loop to keep MeeBot swaying left and right while the intro music is playing, and then have MeeBot start dancing when other music starts.
 
 There’s intro music playing while MeeBot waits to start his dance routine. MeeBot should only sway left and right while the intro is playing. Only when the intro stops and the other music starts should MeeBot begin to dance.
 
 Now is a good time to use a [while loop](glossary://while%20loop). Reminder: while loops allow you to determine when your code will run. A while loop runs a code block for as long as a [Boolean](glossary://boolean) [condition](glossary://conditional%20code) is true. When the condition is false, the while loop stops running.
 
 1. Choose a Boolean condition for your while loop to determine when MeeBot should sway.
 2. Enter the dance moves after the while loop to start the dancing when the condition changes.
 3. Tap **Run My Code** and see how MeeBot responds to your code.
*/
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, musicIntro, musicBitBitLoop)
while isPlaying(song:/*#-editable-code*/musicIntro/*#-end-editable-code*/){
    moveToLeft()
    moveToRight()
}
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward(), raiseHands(), bend(), happy(), split(), skip(), twist(), stepAndShake(), bendAndTwist(), crazyDance(), shake(), wave(), swagger(), moveToLeft(beats:), moveToRight(beats:), moveForward(beats:), moveBackward(beats:), raiseHands(beats:), bend(beats:), happy(beats:), split(beats:), skip(beats:), twist(beats:), stepAndShake(beats:), bendAndTwist(beats:), crazyDance(beats:), shake(beats:), wave(beats:), swagger(beats:), moveBody(beats:), moveBody(beats:moves:), moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:), moveLeftArm(angle:beats:), moveRightArm(angle:beats:), moveLeftLeg(angle:beats:), moveRightLeg(angle:beats:), moveLeftFoot(angle:beats:), moveRightFoot(angle:beats:))
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code


