//
//  Assessment.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

let empty = NSLocalizedString("### TODO:", comment:"Empty message")

let success = NSLocalizedString("### Congratulations!\nYou’ve now seen what a talented dancer MeeBot is. Continue to learn MeeBot’s dance moves.\n\n[**Next Page**](@next)", comment:"Success message")


public func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    return commands.count > 2 ? .pass(message: success) : .fail(hints: [empty], solution: nil)
}
