//
//  Assessment.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

let success = NSLocalizedString("### Cool!\nYou have learned two methods for creating dance moves. \n\n[**Next Page**](@next)", comment:"Success message")

let empty_tip = NSLocalizedString("Use `moveLeftArm()` or other simple dance move commands and `moveBody(){}` to  create two dance moves for MeeBot.", comment:"Tip message")

let number_tip = NSLocalizedString("You can make it. Use `moveBody(){}` to create a complex dance move.", comment:"Tip message")

let solution = "moveBody(){\n\tmoveLeftArm(60)\n\tmoveRightArm(-60)\n\tmoveLeftLeg(0)\n}"

public func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    let cs = commands.flatMap{$0.action == .start || $0.action == .finish ? nil : $0}
    if cs.count == 1 {
        return .fail(hints: [empty_tip], solution: nil)
    }
    if let last = cs.last, let vs = last.variables {
        if vs.reduce(0, {$0 + ($1 == "nil" ? 0 : 1)}) > 1 {
            return .pass(message: success)
        }
    }
    return .fail(hints: [number_tip], solution: solution)
}



