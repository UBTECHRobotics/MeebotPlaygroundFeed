//
//  Assessment.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

let success = NSLocalizedString("### Well done.\nYou have created a dance routine.\n\n[**Next Page**](@next)", comment:"Success message")

let tip = NSLocalizedString("Don’t forget to add dance moves to finish declaring a function before you call the function.", comment:"Tip message")

public func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    return commands.count > 2 ? .pass(message: success) : .fail(hints: [tip], solution: nil)
}
