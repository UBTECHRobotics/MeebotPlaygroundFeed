//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
//#-hidden-code
import SceneKit
import PlaygroundSupport
//#-end-hidden-code
/*:#localized(key: "FirstProseBlock")
 **Goal**: Use a function to create a dance routine for MeeBot.
 
 A dance routine is a series of planned steps. Often, a specific dance routine is performed over and over again. If you write down the moves one by one, every single time, the code would be long and repetitive. This is when a [function](glossary://function) can help. You can create a function for your dance routine and give it a name so you can call it the next time you want MeeBot to perform that routine.
 
 1. Create a function for your dance routine and give it a distinct name. You can create as many different dance routines as you'd like.
 2. Tap **Run My Code** to see how MeeBot responds to your code.
 */
//#-hidden-code
playgroundPrologue()
//#-end-hidden-code
func myDanceRoutine() {
    //#-code-completion(everything, hide)
    //#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward(), raiseHands(), bend(), happy(), split(), skip(), twist(), stepAndShake(), bendAndTwist(), shake(), wave(), swagger(), crazyDance())
    //#-editable-code Tap to enter code
    //#-end-editable-code
}
myDanceRoutine()
//#-hidden-code
playgroundEpilogue()
//#-end-hidden-code


