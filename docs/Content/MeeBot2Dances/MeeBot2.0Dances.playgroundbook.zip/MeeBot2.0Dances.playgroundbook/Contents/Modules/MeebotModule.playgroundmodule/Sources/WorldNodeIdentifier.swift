// 
//  WorldNodeIdentifier.swift
//
//  Created by Chao He on 2017/2/27.
//  Copyright © 2017年 UBTech Inc. All rights reserved.
//

import SceneKit

// MARK: GridNodeIdentifier

// Important nodes pertaining to the construction of the grid
let GridNodeName = "Stage"
let CameraHandleName = "CameraHandle"
let CameraNodeName = "camera"
let RootNodeName = "rootNode"
let ActorNodeName = "Meebot_v4"

public let meebotPath = "ComponentsForLevels/MeeBot/\(ActorNodeName)"
public let commonMapPath = "CommonMap/map_v10"
public let level1Path = "Level_1/level-1_v15"
public let level2Path = "Level_2/level-2_v15"
public let level4Path = "Level_4/Level_4"
public let level5Path = "Level_5/Level_5"
