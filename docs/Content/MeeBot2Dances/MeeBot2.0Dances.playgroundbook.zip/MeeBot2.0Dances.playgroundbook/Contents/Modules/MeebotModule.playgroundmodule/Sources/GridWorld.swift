//
//  GridWorld.swift
//  PlaygroundScene
//
//  Created by Chao He on 2017/2/27.
//  Copyright © 2017年 UBTech Inc. All rights reserved.
//

import UIKit
import SceneKit

public class GridWorld: NSObject {
    var gridNode: GridNode?
    var rootNode: SCNNode
    var actorCoordinate: Coordinate = .init(column: 0, row: 0)
    var startPosition: Coordinate = .init(column: 0, row: 0)
    var actorFacing: Direction = .south
    
    init(node: SCNNode, actorCoordinate: Coordinate, facing: Direction) {
        rootNode = node
        self.gridNode = GridNode(with: node)
        self.actorFacing = facing
        self.actorCoordinate = actorCoordinate
        self.startPosition = actorCoordinate
        super.init()
    }
    
    var actorWorldCoordinate : SCNVector3 {
//        guard let gridRootNode = self.gridNode?.rootNode else { return SCNVector3Zero }
//        return rootNode.convertPosition(actorCoordinate.position, from: gridRootNode)
        return rootNode.childNode(withName: "Block-\(actorCoordinate.row)\(actorCoordinate.column)", recursively: true)!.worldPosition
    }
    
    func isCellExists(with row: Int, and column: Int) -> Bool {
        return rootNode.childNode(withName: "Block-\(row)\(column)", recursively: true) != nil
    }
    
    func convertToGrid(position: SCNVector3) -> SCNVector3 {
        guard let gridRootNode = self.gridNode?.rootNode else { return SCNVector3Zero }
        return rootNode.convertPosition(position, to: gridRootNode)
    }
    
    func convertFromGrid(position: SCNVector3) -> SCNVector3 {
       guard let gridRootNode = self.gridNode?.rootNode else { return SCNVector3Zero }
       return rootNode.convertPosition(position, from: gridRootNode)
    }
    
    var actorFacingAngle: Float {
        return actorFacing.radians
    }
}
