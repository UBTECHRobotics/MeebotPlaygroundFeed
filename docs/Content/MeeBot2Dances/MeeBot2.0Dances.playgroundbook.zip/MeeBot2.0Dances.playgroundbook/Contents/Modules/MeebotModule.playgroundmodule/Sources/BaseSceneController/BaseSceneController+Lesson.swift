//
//  SceneController+Lesson.swift
//  PlaygroundScene
//
//  Created by newman on 17/3/23.
//  Copyright © 2017年 UBTech Inc. All rights reserved.
//

import Foundation
import UIKit
import AVFoundation
import SceneKit

public enum Lesson: String {
    case lessonNone = "none"
    case lesson1 = "first Lesson"
    case lesson2 = "second Lesson begin"
    case lesson2_1 = "second Lesson end"
    case lesson3 = "third Lesson"
    case lesson3_1 = "third Lesson use set"
    case lesson3_2 = "third Lesson end"
    case lesson4   = "forth lesson"
    case lesson4_1 = "forth lesson end"
    
    case lesson5
    
    case lesson6 = "sixth lesson"

    case lesson7
    
    case lesson8
    
    case lesson9 = "last lesson"
}

