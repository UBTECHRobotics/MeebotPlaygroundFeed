//
//  SensorLessonViewController.swift
//  PlaygroundBook
//
//  Created by Dev on 12.05.2020.
//

import UIKit
import SceneKit
import PlaygroundSupport
import EndCutscene

public class SensorLessonViewController: UIViewController {
    private let sceneView = SCNView()
    
    private var rootNode: SCNNode { return sceneView.scene!.rootNode }
    
    private var redLampOn: SCNNode { return rootNode.childNode(withName: "redLampOn", recursively: true)! }
    private var redLampOff: SCNNode { return rootNode.childNode(withName: "redLampOff", recursively: true)! }
    private var greenLampOn: SCNNode { return rootNode.childNode(withName: "greenLampOn", recursively: true)! }
    private var greenLampOff: SCNNode { return rootNode.childNode(withName: "greenLampOff", recursively: true)! }
    private var blueLampOn: SCNNode { return rootNode.childNode(withName: "blueLampOn", recursively: true)! }
    private var blueLampOff: SCNNode { return rootNode.childNode(withName: "blueLampOff", recursively: true)! }
    
    private var eyesOff: SCNNode { return rootNode.childNode(withName: "eyesOff", recursively: true)! }
    private var whiteEyes: SCNNode { return rootNode.childNode(withName: "whiteEyes", recursively: true)! }
    private var greenEyes: SCNNode { return rootNode.childNode(withName: "greenEyes", recursively: true)! }
    private var yellowEyes: SCNNode { return rootNode.childNode(withName: "yellowEyes", recursively: true)! }
    private var blueEyes: SCNNode { return rootNode.childNode(withName: "blueEyes", recursively: true)! }
    private var redEyes: SCNNode { return rootNode.childNode(withName: "redEyes", recursively: true)! }
    
    private var wasFirstTapOnLamp = false
    private var isTapEnabled = true
    
    private var blinkingEyesActions: [Selector]!
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupActions()
        setupView()
        setupAnimations()
        setupInitialState()
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        PlaygroundPage.current.assessmentStatus = .fail(hints: [NSLocalizedString("Tap and hold on any lamp", comment: "Hint")], solution: nil)
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        lampOn(location: touches.first!.location(in: sceneView))
    }
    
    private func setupActions() {
        blinkingEyesActions = [#selector(redEyesAction), #selector(yellowEyesAction), #selector(greenEyesAction), #selector(blueEyesAction)]
    }

    @objc func redEyesAction() {
        self.whiteEyes.isHidden = true
        self.redEyes.isHidden = false
    }
    
    @objc func yellowEyesAction() {
        self.greenEyes.isHidden = true
        self.yellowEyes.isHidden = false
        perform(#selector(greenEyesAction), with: nil, afterDelay: 0.66)
    }
    
    @objc func greenEyesAction() {
        self.yellowEyes.isHidden = true
        self.greenEyes.isHidden = false
    }
    
    @objc func blueEyesAction() {
        self.isTapEnabled = true
        self.setupInitialState()
    }
    private func setupView() {
        sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(sceneView)
        sceneView.frame = view.bounds
        sceneView.backgroundColor = UIColor.clear
        sceneView.scene = SCNScene(named: "WorldResources.scnassets/_Scenes/Level_5/LightSensor/light_sensor.scn")!
        sceneView.showsStatistics = MACRO_DEBUG
    }
    
    private func setupAnimations() {
        let emptyAction = SCNAction.customAction(duration: 1) { (_, _) in }
        rootNode.runAction(SCNAction.repeatForever(emptyAction))
    }
    
    private func setupInitialState() {
        redEyes.isHidden = true
        blueEyes.isHidden = true
        whiteEyes.isHidden = true
        greenEyes.isHidden = true
        yellowEyes.isHidden = true
        
        redLampOn.isHidden = true
        blueLampOn.isHidden = true
        greenLampOn.isHidden = true
        
        for blinkingEyesAction in blinkingEyesActions {
            NSObject.cancelPreviousPerformRequests(withTarget: self, selector: blinkingEyesAction, object: nil)
        }
    }
    
    private func lampOn(location: CGPoint) {
        let results = sceneView.hitTest(location, options: nil)
        var finishDelay: Double = 2
        
        for result in results {
            let node = result.node
            switch node.name {
            case redLampOff.name:
                isTapEnabled = false
                setupInitialState()
                redLampOn.isHidden = false
                whiteEyes.isHidden = false
                perform(#selector(redEyesAction), with: nil, afterDelay: 1)
            case greenLampOff.name:
                isTapEnabled = false
                setupInitialState()
                greenLampOn.isHidden = false
                greenEyes.isHidden = false
                perform(#selector(yellowEyesAction), with: nil, afterDelay: 0.66)
            case blueLampOff.name:
                isTapEnabled = false
                setupInitialState()
                blueLampOn.isHidden = false
                blueEyes.isHidden = false
                finishDelay = 2.0 * 1.0 / 0.85
            default: break
            }
            
            if !isTapEnabled { break }
        }
        
        if isTapEnabled { return }

        if !wasFirstTapOnLamp && !isInitialState() {
            PlaygroundPage.current.assessmentStatus = .pass(message: NSLocalizedString("### Well done.\nYou now know what a color sensor is\n\n[**Next Page**](@next)", comment:"Success message"))
            wasFirstTapOnLamp = true
        }

        perform(#selector(blueEyesAction), with: nil, afterDelay: finishDelay)
    }
    
    private func isInitialState() -> Bool {
        return redLampOn.isHidden && blueLampOn.isHidden && greenLampOn.isHidden
    }
}
