//
//  SceneController.swift
//  JimuPlaygroundBook
//
//  Created by hechao on 2016/12/26.
//  Copyright © 2016年 UBTech Inc. All rights reserved.
//

import SceneKit

class SceneController: BaseSceneController {
    let scnView = SCNView()
    var cameraController: CameraController?
    
    override var rootNode: SCNNode? {
        return scnView.scene?.rootNode
    }
    
    // MARK: Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        isEnvironmentReadyToExecuteCommands = { callback in
            callback()
        }
        let scene = self.scene.scnScene
        DispatchQueue.main.async {
            self.scnView.scene = scene
            self.scnView.scene?.background.contents = self.scene.environmentLight?.contents
            self.scnView.scene?.lightingEnvironment.contents = self.scene.environmentLight?.contents
            self.scnView.scene?.lightingEnvironment.intensity = self.scene.environmentLight?.intensity ?? 1
            self.addGeomtries()
            self.sceneDidLoad(scene)
            switch self.userLesson {
                case .lesson1, .lessonNone:
                    self.addLesson1Animations()
                    self.scnView.scene?.rootNode.childNode(withName: "MeebotLight", recursively: true)?.isHidden = false
                case .lesson4:
                    self.scnView.scene?.rootNode.childNode(withName: "MeebotLight", recursively: true)?.isHidden = false
                default:
                break
            }
        }
        scnView.contentMode = .center
        configureViewForDevice()
    }
    
    // Layout
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        cameraController?.resetCamera()
    }
    
    override func addViews() {
        scnView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(scnView)
        scnView.frame = view.bounds
        scnView.backgroundColor = UIColor.clear
        scnView.showsStatistics = MACRO_DEBUG
        super.addViews()
    }
    
    /// Add geomtries to the scene view
    private func addGeomtries() {
        // Get root node
        let rootNode = scnView.scene?.rootNode
        // Get geometries root node
        /// actor
        let actorNode = getRootNodeWithSceneName(sceneName: meebotPath)
        actorNode.name = ActorNodeName
        rootNode?.addChildNode(actorNode)
        actorNode.worldPosition = scene.gridWorld.actorWorldCoordinate
        actorNode.eulerAngles.y = scene.gridWorld.actorFacingAngle
        scnView.autoenablesDefaultLighting = true
        levelPath.setupPath(lesson: self.userLesson!, gridWorld: scene.gridWorld, robotNode: scene.rootNode.childNode(withName: ActorNodeName, recursively: true)!)
    }
    
    // MARK: sceneDidLoad
    /// Called after the scene has been manually assigned to the SCNView.
    private func sceneDidLoad(_: SCNScene) {
        // Now that the scene has been loaded, trigger a
        // verification pass.
        
        
        // Set controller after scene has been initialized on `scnView`.
        cameraController = CameraController(view: scnView, facing: scene.gridWorld.actorFacing)
        
        if userLesson == .lesson9 {
            // Persisted current lesson is last
            Persisted.isLastLesson = true
            
            // music From Lib
            if let music = Persisted.musicNameFromLib {
                self.songArray.append(music)
            }
        } else {
            Persisted.isLastLesson = false
        }
     }
    
    /// config view
    func configureViewForDevice() {
        // Grab the device from the scene view and interrogate it.
        #if targetEnvironment(simulator)
            scnView.contentScaleFactor = 1.5
            scnView.preferredFramesPerSecond = 30
        #else
            if let defaultDevice = scnView.device,
                defaultDevice.supportsFeatureSet(.iOS_GPUFamily2_v2) {
                scnView.antialiasingMode = .multisampling2X
            }
        #endif
    }

    /// Gesture
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)

        if (presentedViewController as? GuideViewController) != nil{
            return
        }
        if let pc = presentedViewController{
            pc.dismiss(animated: true, completion: nil)
        }
    }
    
    private func addLesson1Animations() {
        guard
            let oceanNode = scnView.scene?.rootNode.childNode(withName: "ocean", recursively: true),
            let pierLights = scnView.scene?.rootNode.childNode(withName: "pier", recursively: true)?.childNodes.last else { return }
        
        //Animate poles
        pierLights.firstGeometry?.firstMaterial?.emission.intensity = 0
        let a = SCNAction.customAction(duration: 1) { (node, value) in
            node.firstGeometry?.firstMaterial?.emission.intensity = value
        }
        a.timingMode = .easeInEaseOut
        
        let b = SCNAction.customAction(duration: 1) { (node, value) in
            node.firstGeometry?.firstMaterial?.emission.intensity = 1-value
        }
        let loop = SCNAction.repeatForever(SCNAction.sequence([a,b]))
        pierLights.runAction(loop)
        
        // Animate Ocean
        let oceanAction = SCNAction.customAction(duration: 512) { (node, value) in
            oceanNode.firstGeometry?.firstMaterial?.normal.contentsTransform = SCNMatrix4MakeTranslation(Float(value) * 0.1, Float(value) * 0.002, 0)
        }
        oceanNode.runAction(SCNAction.repeatForever(oceanAction))
    }
}
