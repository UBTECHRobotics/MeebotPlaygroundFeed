//
//  File.swift
//  PlaygroundScene
//
//  Created by Chao He on 2017/2/27.
//  Copyright © 2017年 UBTech Inc. All rights reserved.
//
import UIKit
import AVFoundation
import SceneKit
import PlaygroundSupport
import MediaPlayer
import EndCutscene

/// An indication that the conforming type functions as a control element in the
/// `SceneController`.
protocol WorldControl {}

extension BaseSceneController: PlaygroundLiveViewSafeAreaContainer {
    internal class OverlayView: UIView, WorldControl {
        init() {
            let blurEffect = UIBlurEffect(style: .extraLight)
            let blurEffectView = UIVisualEffectView(effect: blurEffect)
            blurEffectView.layer.cornerRadius = 22
            blurEffectView.clipsToBounds = true
            blurEffectView.translatesAutoresizingMaskIntoConstraints = true
            blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            
            super.init(frame: CGRect.zero)
            
            addSubview(blurEffectView)
            blurEffectView.frame = bounds
            
            let whiteOverBlurView = UIView()
            whiteOverBlurView.translatesAutoresizingMaskIntoConstraints = true
            whiteOverBlurView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            whiteOverBlurView.frame = bounds
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }
    
    // MARK: Layout constants
    
    struct ControlLayout {
        static let verticalOffset: CGFloat = 18
        static let height: CGFloat = 44
        static let width: CGFloat = 44
        static let edgeOffset: CGFloat = 20
    }
    
    func announceBpmOfMusic(_ bpm: UInt) {
        let accessibilityString = String(format: NSLocalizedString("The BPM of currently playing music is %d", comment: "Accessibility announcement for current song BPM"), bpm)
        liveLog(accessibilityString)
        self.announce(speakableDescription: accessibilityString)
    }
    
    @objc func announceCurrentBpm() {
        self.announceBpmOfMusic(self.bpm)
    }
    
    // MARK: Control buttons
    func addControlButtons() {
        // Audio button
        let audioContainer = OverlayView()
        view.addSubview(audioContainer)
        
        audioContainer.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            audioContainer.topAnchor.constraint(equalTo: liveViewSafeAreaGuide.topAnchor, constant: ControlLayout.verticalOffset),
            audioContainer.leftAnchor.constraint(equalTo: view.leftAnchor, constant: ControlLayout.edgeOffset),
            audioContainer.heightAnchor.constraint(equalToConstant: ControlLayout.height),
            audioContainer.widthAnchor.constraint(equalToConstant: ControlLayout.width)
        ])
        
        updateAudioButtonImage()
        audioButton.imageView?.contentMode = .scaleAspectFit
        audioButton.translatesAutoresizingMaskIntoConstraints = true
        audioButton.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        audioButton.accessibilityLabel = NSLocalizedString("Music Menu", comment: "Music Menu Button")
        
        audioButton.addTarget(self, action: #selector(adjustAudioAction(_:)), for: .touchUpInside)
        audioContainer.addSubview(audioButton)
        
        // Bluetooth
        // playgroundBluetoothConnectionView
        let topConstraint = playgroundBluetoothConnectionView.topAnchor.constraint(equalTo: liveViewSafeAreaGuide.topAnchor, constant: ControlLayout.verticalOffset)
        let horizontalConstraint = playgroundBluetoothConnectionView.trailingAnchor.constraint(equalTo: liveViewSafeAreaGuide.trailingAnchor, constant: -ControlLayout.edgeOffset)
        view.addSubview(playgroundBluetoothConnectionView)
        NSLayoutConstraint.activate([topConstraint, horizontalConstraint])
    }
    
    func testingAnimations(count: Int) {
        let completionForRecursive = count == 0 ? {} : {self.testingAnimations(count: count - 1)}
        if colorSensorDetects("blue") {
            self.runCommonAnimation(.moveForward)
            delay(5) {
                completionForRecursive()
            }
        } else {
            self.runCommonAnimation(.turnLeft)
            delay(5) {
                if colorSensorDetects("blue") {
                    self.runCommonAnimation(.moveForward)
                    delay(5) {
                        completionForRecursive()
                    }
                } else {
                    self.runCommonAnimation(.turnRight)
                    delay(5) {
                        self.runCommonAnimation(.turnRight)
                        delay(5) {
                            self.runCommonAnimation(.moveForward)
                            delay(5) {
                                completionForRecursive()
                            }
                        }
                    }
                }
            }
        }
    }
    
    @objc func adjustAudioAction(_ button: UIButton) {
        // Dismiss a previous presented `AudioMenuController`.
//        testingAnimations(count: 12)
        if let vc = presentedViewController as? UINavigationController {
            vc.dismiss(animated: true, completion: nil)
            return
        } else {
            if let pc = presentedViewController{
                pc.dismiss(animated: true, completion: nil)
            }
            
            let audioMenuController = AudioMenuController(songArray: songArray, menuDelegate: self)
            self.audioMenu = audioMenuController

            let navigationController = UINavigationController(rootViewController: audioMenuController)
            
            navigationController.modalPresentationStyle = .popover
            navigationController.popoverPresentationController?.passthroughViews = [view]
            
            navigationController.popoverPresentationController?.permittedArrowDirections = .up
            navigationController.popoverPresentationController?.sourceView = button
            
            // Offset the popup arrow under the button.
            navigationController.popoverPresentationController?.sourceRect = CGRect(x: 0, y: 5, width: 44, height: 44)
        
            navigationController.popoverPresentationController?.delegate = self
            audioMenuController.menuMusicPickerDelegate = self
            present(navigationController, animated: true, completion: nil)
        }
    }
    
    func showControlButton(show: Bool) {
        if show {
            audioButton.isHidden = false
            audioButton.superview?.isHidden = false
            
        } else {
            audioButton.isHidden = true
            audioButton.superview?.isHidden = true
        }
    }
}

extension BaseSceneController: UIPopoverPresentationControllerDelegate {
    // MARK: UIPopoverPresentationControllerDelegate
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
    /// Dismisses the audio menu if visible.
    func dismissAudioMenu() {
        dismiss(animated: true, completion: nil)
    }
}

// MARK: Audio Delegate
extension BaseSceneController: AudioMenuControllerDelegate, AudioMenuMusicPickerDelegate {
    func enableAudioMenuSelect(_ isEnabled: Bool) {
        liveLog("enableAudioMenuSelect")
        // Persist the choice.
        Persisted.isBackgroundAudioEnabled = isEnabled
        updateAudioButtonImage()
        
        self.isAudioOpen = isEnabled
        
        if isEnabled {
            let songName = songArray[Int(Persisted.backgroudAudioSelectedIndex)]
//            if buildInSongArray.contains(songName) {
                self.play(songName: songName)
//            } else {
//                self.play(songName: songName, .MPmusicPlayer)
//            }
        } else {
            self.stop()
            self.pause(.MPmusicPlayer)
        }
    }
    
    func playSongAt(index: Int) {
        liveLog("playSongAt \(index)")
        if self.isAudioOpen {
            
            let songName = songArray[index]
            
//            if buildInSongArray.contains(songName) {
                self.play(songName: songName)
//            } else {
//                self.play(songName: songName, .MPmusicPlayer)
//            }

        }

    }
    
    func mediaPickerDidPickMediaItem(mediaItemCollection: MPMediaItemCollection) {
        if let item = mediaItemCollection.items.first, let musicName = item.title {
            if self.songArray.count < buildInMusicCount + 1 {
                self.songArray.append(musicName)
            }
            else {
                self.songArray.removeLast()
                self.songArray.append(musicName)
            }
            
            musicPlayer.setQueue(with: mediaItemCollection)
            
            if Persisted.backgroudAudioSelectedIndex == buildInMusicCount {
                musicPlayer.play()
            }
        }
    }
}

// MARK: Audio
extension BaseSceneController {
    func updateAudioButtonImage(on: Bool = Persisted.isBackgroundAudioEnabled) {
        let image: UIImage?
        if on {
            image = UIImage(named: "music_on")
        }
        else {
            image = UIImage(named: "music_off")
        }
        
        audioButton.setImage(image, for: .normal)
    }
    
    func playAudioIfAudioIsOpen() {
        if self.isAudioOpen {
            let index = (Persisted.backgroudAudioSelectedIndex < songArray.count) ? Persisted.backgroudAudioSelectedIndex : 0
            let songName = songArray[index]
            
//            if buildInSongArray.contains(songName) {
                self.play(songName: songName)
//            } else {
//                self.play(songName: songName, .MPmusicPlayer)
//            }
        }
    }
    
    func pauseAudioIfAppEnterBackground() {
        if self.isAudioOpen {
            let index = (Persisted.backgroudAudioSelectedIndex < songArray.count) ?Persisted.backgroudAudioSelectedIndex : 0
            let songName = songArray[index]
            
//            if buildInSongArray.contains(songName) {
                self.pause()
//            } else {
//                self.pause(.MPmusicPlayer)
//            }
        }
    }
}
