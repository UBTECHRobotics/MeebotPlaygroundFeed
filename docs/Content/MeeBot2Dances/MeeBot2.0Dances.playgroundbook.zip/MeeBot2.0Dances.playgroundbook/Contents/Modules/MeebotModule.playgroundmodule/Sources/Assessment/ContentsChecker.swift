// 
//  ContentsChecker.swift
//
//  Copyright © 2016,2017 Apple Inc. All rights reserved.
//

import Foundation

let blackListCalls = [
    "playgroundPrologue",
    "playgroundEpilogue",
]

public class ContentsChecker {
    let contents: String
    let nodes: [Node]
    
    public let numberOfStatements: Int
    
    public init(contents: String) {
        self.contents = contents
        
        let tokens = TokenGenerator(content: contents).reduce([]) { tokens, currentToken in
            return tokens + [currentToken]
        }
        
        let parser = SimpleParser(tokens: tokens)
        
        let nodes: [Node]
        do {
            nodes = try parser.createNodes()
        }
        catch {
            nodes = []
//            log(message: "Contents Parser error: \(error).")
        }
        
        let filteredNodes = nodes.filter { node in
            // Exclude function calls identified by the `blackListCalls`.
            if let call = node as? CallNode {
                return !blackListCalls.contains(call.identifier)
            }
            return true
        }
        self.nodes = filteredNodes
        
        numberOfStatements = filteredNodes.reduce(0) { $0 + $1.lineCount }
    }
    
    func nodesOfType<T: Node>(_ type: T.Type) -> [T] {
        return nodes.flatMap { node -> [T] in
            var subNodes = [node]
            if let statement = node as? Statement {
                 subNodes += statement.flattenedBodyNodes
            }
            
            return subNodes.compactMap { $0 as? T }
        }
    }
    
    public lazy var definitionNodes: [DefinitionNode] = self.nodesOfType(DefinitionNode.self)
    public lazy var conditionalNodes: [ConditionalStatementNode] = self.nodesOfType(ConditionalStatementNode.self)
    
    public var didUseConditionalStatement: Bool {
        return !conditionalNodes.isEmpty
    }
    
    public func didUseConditionalStatement(_ name: String) -> Bool {
        guard let word = Keyword(rawValue: name) else { return false }
        return conditionalNodes.contains {
            $0.type == word
        }
    }
    
    public func function(_ name: String, matchesCalls calls: [String]) -> Bool {
        guard let functionNode = definitionNodes.first else { return false }
        guard !functionNode.body.isEmpty else { return false }
        
        let sanitizedCalls: [String] = calls.map {
            if $0.hasSuffix("()") {
                return String($0.dropLast(2))
            }
            return $0
        }
        
        guard functionNode.body.count == sanitizedCalls.count else { return false }
        for (bodyNode, check) in zip(functionNode.body, sanitizedCalls) {
            guard let call = bodyNode as? CallNode else { continue }
            
            if call.identifier != check {
                return false
            }
        }
        
        return true
    }
}
