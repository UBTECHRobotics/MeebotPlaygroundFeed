//
//  LevelPath.swift
//  LiveViewTestApp
//
//  Created by Dev on 24.04.2020.
//

import SceneKit

public class LevelPath {
    public var path: [(row: Int, column: Int)]?
    public var currentCell: (row: Int, column: Int)!
    public var currentIndex = 0
    public var robotNode: SCNNode?
    public var gridWorld: GridWorld
    public var initialAngle: Float!
    
    public init() {
        self.robotNode = nil
        self.gridWorld = GridWorld(node: SCNNode(), actorCoordinate: Coordinate(column: 1, row: 0), facing: .south)
        self.currentCell = (row: 0, column: 1)
    }
    
    public init(lesson: Lesson, gridWorld: GridWorld, robotNode: SCNNode?) {
        self.robotNode = robotNode
        self.gridWorld = gridWorld
        self.currentCell = (row: gridWorld.actorCoordinate.row, column: gridWorld.actorCoordinate.column)
        self.initialAngle = robotNode?.eulerAngles.y
    }
    
    public func setupPath(lesson: Lesson, gridWorld: GridWorld, robotNode: SCNNode?) {
        liveLog("levelPath setupPath")
        self.robotNode = robotNode
        self.gridWorld = gridWorld
        self.currentCell = (row: gridWorld.actorCoordinate.row, column: gridWorld.actorCoordinate.column)
        self.initialAngle = robotNode?.eulerAngles.y
        switch lesson {
        case .lesson5:
            liveLog("levelPath setupPath in case \(lesson.rawValue)")
            path = [(0, 1), (1, 1), (1, 0), (2, 0), (2, 1), (2, 2), (1, 2), (1, 3), (2, 3), (3, 3), (3, 2), (3, 1), (3, 0), (4, 0)]
        default: break
        }
    }
    
    public func setNextCell(row: Int, column: Int) {
        guard let path = path else { return }
        let coordinate = (row: row, column: column)
        currentIndex = path.firstIndex {$0 == coordinate} ?? 0
        currentCell = path[currentIndex]
    }
    
    public func reset() {
        currentIndex = 0
        currentCell = (row: gridWorld.startPosition.row, column: gridWorld.startPosition.column)
        guard let robotNode = robotNode else { return }
        gridWorld.actorCoordinate = gridWorld.startPosition
        robotNode.position = gridWorld.actorWorldCoordinate
        robotNode.eulerAngles.y = initialAngle
    }
    
    public func isCellToMoveAvailableToWalk(action: Action = .moveForward) -> Bool {
        liveLog("levelPath isCellToMoveAvailableToWalk before chacking path variable")
        guard let path = path else { return true }
        liveLog("levelPath isCellToMoveAvailableToWalk after chacking path variable")
        guard let robotYAngle = robotNode?.eulerAngles.y else { return false }
        var index = 0
        let nextCellIndex = (currentIndex + 1) == path.count ? currentIndex : currentIndex + 1
        let previosCellIndex = currentIndex == 0 ? currentIndex : currentIndex - 1
        
        switch action {
        case .moveForward: index = 0
        case .moveToRight: index = 1
        case .moveBackward: index = 2
        case .moveToLeft: index = 3
        default: break
        }
        
        let forwardDirectionVector = gridWorld.actorFacing.getRobotDirectionVector(angle: robotYAngle)[index]
        let cellToMove = (row: currentCell.row + forwardDirectionVector.row, colum: currentCell.column + forwardDirectionVector.column)
        
        liveLog("levelPath isCellToMoveAvailableToWalk after chacking path variable \(index) \(nextCellIndex) \(previosCellIndex) \(robotYAngle) \(path) \(forwardDirectionVector) \(cellToMove) \(path[nextCellIndex]) \(path[previosCellIndex]) \(path[nextCellIndex] == cellToMove || path[previosCellIndex] == cellToMove)")
        return path[nextCellIndex] == cellToMove || path[previosCellIndex] == cellToMove
    }
    
    public func isFinalCell() -> Bool {
        guard let path = path else { return true }
        return path[path.count - 1] == currentCell
    }
}
