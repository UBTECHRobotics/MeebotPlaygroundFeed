//
//  VideoViewController.swift
//  PlaygroundBook
//
//  Created by Dev on 02.05.2020.
//

import AVKit
import PlaygroundSupport

public class VideoViewController: AVPlayerViewController {
    override public func viewDidLoad() {
        view.backgroundColor = .black
        guard let url = Bundle.main.url(forResource: "light_sensor_diagram", withExtension: "mp4") else { return }
        player = AVPlayer(url: url)
        player?.play()
        player?.actionAtItemEnd = .none
        NotificationCenter.default.addObserver(self, selector: #selector(playerItemDidReachEnd(notification:)), name: .AVPlayerItemDidPlayToEndTime, object: player?.currentItem)
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        PlaygroundPage.current.assessmentStatus = .pass(message: NSLocalizedString("### Well done.\nYou now know what a color sensor is\n\n[**Next Page**](@next)", comment:"Success message"))
    }
    
    @objc func playerItemDidReachEnd(notification: Notification) {
        if let playerItem = notification.object as? AVPlayerItem {
            playerItem.seek(to: CMTime.zero, completionHandler: nil)
        }
    }
}
