////
//  Book_Sources
//
//  Created by George Michael on 10/12/2019
//

import ARKit

class ARSceneController: BaseSceneController, ARSCNViewDelegate, ARSessionDelegate {    
    private var informationLabel: UILabel = UILabel(frame: CGRect(x:0, y:0, width:100, height:100))
    let arView = ARSCNView()
    var detectedObject: DetectedObject?
    private var objectDetected: Bool = false
    var blurView: UIVisualEffectView?
    private var lastDateDetected: Date = Date()
    private var lastDetectedTimer: Timer?
    private var objectDetectedCallback: () -> () = { }
    let updateQueue = DispatchQueue(label: "com.apple.playgrounds.augmentedreality.serialSceneKitQueue")
    let islandScaleFactor: Float = 0.0035*1.5 //x1.5 as per customer request
    override var running: Bool {
        didSet {
            if running && !objectDetected {
                show(message: ARTextMessage.pointCameraToTheRobot.text)
            }
        }
    }
    
    override var rootNode: SCNNode? {
        return arView.scene.rootNode
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        isEnvironmentReadyToExecuteCommands = { callback in
            guard !self.objectDetected else {
                callback()
                return
            }
            self.objectDetectedCallback = callback
        }
        arView.delegate = self
        let scene = self.scene.scnScene
        arView.scene.lightingEnvironment.contents = self.scene.environmentLight?.contents
        arView.scene.lightingEnvironment.intensity = self.scene.environmentLight?.intensity ?? 1
        self.lastDetectedTimer = Timer.scheduledTimer(timeInterval: 10, target: self, selector: #selector(self.objectDetectionTimerAction), userInfo: nil, repeats: true)
        guard ARWorldTrackingConfiguration.isSupported else {
            displayUnsupportedMessage()
            return
        }
        let path = "WorldResources.scnassets/arobjects/robotModel"
        guard let modelURL = Bundle.main.url(forResource: path, withExtension: "arobject"),
            let arModel = try? ARReferenceObject(archiveURL: modelURL) else {
                print("AR Reference Object is missing at path: \(path)")
                return
        }
        let robotNode = getRootNodeWithSceneName(sceneName: meebotPath)
        detectedObject = DetectedObject(referenceObject: arModel, robotNode: robotNode)
        guard let objectNode = detectedObject else { return }
        arView.scene.rootNode.addChildNode(objectNode)
        arView.session.delegate = self
        arView.automaticallyUpdatesLighting = false
        detectedObject?.set(scene: self.scene, stageNode: scene.rootNode, lesson: self.userLesson)
        switch userLesson {
            case .lessonNone, .lesson2_1:
                addLesson2_1Animations()
            default:
            break
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        running = false
        updateViews()
        setupSession()
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        arView.session.pause()
    }
    
    override func addViews() {
        arView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(arView)
        arView.frame = view.bounds
        view.backgroundColor = .black
        arView.backgroundColor = UIColor.clear
        arView.showsStatistics = MACRO_DEBUG
        setupInformationLabel()
        super.addViews()
    }
    
    // MARK: - ARSCNViewDelegate
    
    var islandNode: SCNNode = SCNNode()
       
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        if let _ = anchor as? ARPlaneAnchor {
            updateQueue.async { [weak self] in
                self?.stopTracking()
                self?.detectedObject?.enumerateChildNodes { n, _ in
                    n.opacity = 0
                }
                self?.displayMap(with: node)
                DispatchQueue.main.async {
                    self?.hideMessage()
                }
            }
            return
        }
        guard let objectAnchor = anchor as? ARObjectAnchor  else {
            return
        }
        guard !objectDetected else { return }
        self.objectDetected = true
        lastDateDetected = Date()
        lastDetectedTimer?.invalidate()
        lastDetectedTimer = nil
        DispatchQueue.main.async { [weak self] in
            self?.hideMessage(completion: {
                self?.show(message: ARTextMessage.objectDetected.text)
                self?.hideMessage(delay: 2.0)
            })
        }
        updateQueue.async { [weak self] in
            guard let vc = self else { return }
            vc.detectedObject?.updateVisualization(newTransform: objectAnchor.transform)
            vc.stopTracking()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                vc.objectDetectedCallback()
                levelPath.setupPath(lesson: vc.userLesson!, gridWorld: vc.scene.gridWorld, robotNode: vc.arView.scene.rootNode.childNode(withName: ActorNodeName, recursively: true)!)
                if vc.userLesson! == .lesson2_1 || vc.userLesson! == .lesson5 {
                    vc.playAudioIfAudioIsOpen()
                }
            }
        }
    }
    
    public func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        DispatchQueue.main.async {
            switch camera.trackingState {
            case .limited(.excessiveMotion):
                self.show(message: ARTextMessage.slowDown.text)
            case .limited(.insufficientFeatures):
                self.show(message: ARTextMessage.moveBackAndForthToFindRobot.text )
            case .limited(.initializing):
               break
            case .notAvailable:
                self.show(message: ARTextMessage.noCamera.text )
            case .limited(.relocalizing):
                self.show(message: ARTextMessage.resuming.text)
            default:
               self.hideMessage()
            }
        }
    }
    
    override func lessonCompleted() {
        switch userLesson {
            case .lesson2_1:
                startPlaneDetection()
//                displayMap(with: detectedObject)
            default:
            break
        }
        
//        liveLog("ar lesson completed")
//        updateViews()
//        startPlaneDetection()
    }

    // MARK: - private methods
    
    private func addLesson2_1Animations() {
        guard
            let oceanNode = scene.rootNode.childNode(withName: "ocean", recursively: true) else { return }
        // Animate Ocean
        let oceanAction = SCNAction.customAction(duration: 512) { (node, value) in
            oceanNode.firstGeometry?.firstMaterial?.normal.contentsTransform = SCNMatrix4MakeTranslation(Float(value) * 0.065, Float(value) * 0.0065, 0)
        }
        oceanNode.runAction(SCNAction.repeatForever(oceanAction))
    }
    
    private func stopTracking() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = []
        arView.debugOptions = []
        arView.session.run(configuration, options: [])
    }
    
    private func displayMap(with node: SCNNode?) {
        guard let node = node else { return }
        let mapScale = islandScaleFactor
        loadingQueue.addOperation {
            let path = "WorldResources.scnassets/_Scenes/" + commonMapPath
            guard
               let sceneURL = Bundle.main.url(forResource: path, withExtension: "scn"),
               let source = SCNSceneSource(url: sceneURL, options: nil) else {
               liveLog("map_v10 is missing")
               return
            }
            let sourceScene = try! source.scene()
            let islandNode = sourceScene.rootNode
            islandNode.scale = SCNVector3(mapScale,mapScale,mapScale)
            islandNode.worldPosition.z -= 1
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 1
            SCNTransaction.completionBlock =  {
                node.addChildNode(islandNode)
                SCNTransaction.begin()
                SCNTransaction.animationDuration = 1
                islandNode.opacity = 1
                SCNTransaction.commit()
            }
            SCNTransaction.commit()
        }
    }
    
    private func startPlaneDetection() {
        updateQueue.async { [weak self] in
            self?.detectedObject?.enumerateChildNodes { n, _ in
                n.opacity = 0
            }
        }
        DispatchQueue.main.async {
            self.show(message: ARTextMessage.pointCameraToFlatSurface.text)
        }
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        arView.session.run(configuration, options: [])
    }
    
    private func setupSession() {
        let path = "WorldResources.scnassets/arobjects/Cut"
        guard
            let arModel = detectedObject?.referenceObject else {
                print("AR Reference Object is missing at path: \(path)")
                return
        }
        let configuration = ARWorldTrackingConfiguration()
        configuration.detectionObjects = [arModel]
        arView.session.run(configuration, options: [])
    }
    
    private func setupInformationLabel() {
        view.addSubview(informationLabel)
        informationLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addConstraints( [
            NSLayoutConstraint(item: view!, attribute: .bottom, relatedBy: .equal, toItem: informationLabel, attribute: .bottom, multiplier: 1.0, constant: 120),
            NSLayoutConstraint(item: informationLabel, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0),
            NSLayoutConstraint(item: informationLabel, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1.0, constant: 80),
            NSLayoutConstraint(item: informationLabel, attribute: .leftMargin, relatedBy: .greaterThanOrEqual, toItem: view, attribute: .leftMargin, multiplier: 1.0, constant: 0),
            NSLayoutConstraint(item: informationLabel, attribute: .rightMargin, relatedBy: .greaterThanOrEqual, toItem: view, attribute: .rightMargin, multiplier: 1.0, constant: 0)
        ])
        informationLabel.alpha = 0
        informationLabel.text = ""
        informationLabel.textColor = .white
        informationLabel.numberOfLines = 0
        informationLabel.transform = CGAffineTransform(translationX: 0, y: 50)
        informationLabel.textAlignment = .center
        informationLabel.font = UIFont.systemFont(ofSize: 25, weight: .bold)
        informationLabel.layer.shadowColor = UIColor.black.cgColor
        informationLabel.layer.shadowRadius = 3.0
        informationLabel.layer.shadowOpacity = 1.0
        informationLabel.layer.shadowOffset = CGSize(width: 0, height: 0)
        informationLabel.layer.masksToBounds = false
    }
    
    private func show(message: String ) {
        informationLabel.text = message
        UIView.animate(withDuration: 0.7,
                       delay: 0.0,
                       usingSpringWithDamping: 0.4,
                       initialSpringVelocity: 1.0,
                       options: .curveEaseOut, animations: {
            self.informationLabel.alpha = 1
            self.informationLabel.transform = .identity
        })
    }
    
    private func hideMessage(delay: Double = 0.0, completion: @escaping () -> Void = { } ) {
        UIView.animate(withDuration: 0.4, delay: delay, options: [.curveEaseOut], animations: {
           self.informationLabel.alpha = 0
           self.informationLabel.transform = CGAffineTransform(translationX: 0, y: 50)
        }, completion: { completed in
            completion()
            guard completed, !self.objectDetected else { return }
            self.show(message: ARTextMessage.pointCameraToTheRobot.text)
       })
    }
    
    @objc private func objectDetectionTimerAction() {
        guard !objectDetected && running else {
            return
        }
        show(message: ARTextMessage.cantFindRobot.text)
        setupSession()
    }
    
    private func updateViews() {
        UIView.animate(withDuration: 0.7, animations: {
            self.arView.alpha = 1
        })
    }
}
