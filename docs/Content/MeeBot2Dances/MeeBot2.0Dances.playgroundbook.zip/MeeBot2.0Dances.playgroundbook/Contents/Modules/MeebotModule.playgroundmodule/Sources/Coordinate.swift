//
//  Coordinate.swift
//
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import SceneKit

/// Specifies a location (column, row) in a grid of columns and rows.
///
/// - localizationKey: Coordinate
public struct Coordinate {
    let scaleFactor: Float = 1
    
    public var column, row: Int
    
    public init(column: Int, row: Int) {
        self.column = column
        self.row = row
    }
    
    static public func ==(c1: Coordinate, c2: Coordinate) -> Bool {
        return c1.row == c2.row && c1.column == c2.column
    }
}

/// World Positioning
extension Coordinate {
    var position: SCNVector3 {
        let scaledX = SCNFloat(column) * scaleFactor
        let scaledZ = -SCNFloat(row) * scaleFactor
        return SCNVector3(Float(scaledX), 0, Float(scaledZ))
    }
    
    init(_ position: SCNVector3) {
        self.column = Int(round(position.x / scaleFactor))
        self.row = Int(round(-position.z / scaleFactor))
    }
}
extension Coordinate: Hashable {
    public func hash(into hasher: inout Hasher) {
        hasher.combine(row)
        hasher.combine(column)
    }
}
extension Coordinate {
    public func neighbor(inDirection direction: Direction) -> Coordinate {
        return advanced(by: 1, inDirection: direction)
    }
    
    public func advanced(by displacement: Int, inDirection direction: Direction) -> Coordinate {
        // -M_PI_2 to calibrate for 0 in the +z direction (Normally it would be in the +x).
        let dx = Int(round(cos(direction.radians - π / 2))) * displacement
        let dy = Int(round(sin(direction.radians - π / 2))) * displacement
        
        return Coordinate(column: column + dx, row: row + dy)
    }
    
    public mutating func setNewPosition(direction: Direction, action: Action, gridWorld: GridWorld, robotYAngle: Float) {
        var row = self.row
        var column = self.column
        var index = 0
        let directionVectors = direction.getRobotDirectionVector(angle: robotYAngle)
        
        switch action {
        case .moveForward: index = 0
        case .moveToRight: index = 1
        case .moveBackward: index = 2
        case .moveToLeft: index = 3
        default: break
        }
        
        row += directionVectors[index].row
        column += directionVectors[index].column
        
        if gridWorld.isCellExists(with: row, and: column) && levelPath.isCellToMoveAvailableToWalk(action: action) {
            self.row = row
            self.column = column
            levelPath.setNextCell(row: row, column: column)
        }
    }
}
