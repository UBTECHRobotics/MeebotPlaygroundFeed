//
//  SceneController+Command.swift
//  Playground
//
//  Created by WG on 2017/3/24.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

extension BaseSceneController {
    
    var timeScale: Double {
        let mode = PlaygroundPage.current.executionMode
        switch mode {
        case .run:
            return 1
        case .step:
            return 1.5
        case .stepSlowly:
            return 2
        default:
            return 1
        }
    }
    
    func onReceive(_ action:Action, variables:[String]? = nil) {
        currentAction = action
        pageLog("current Action: \(action)")
        liveLog("SCN+Command onReceive")
        switch action {
        case .start:
            starting = true
            tryStarting()
            resetModel()
            playMusic()
        case .finish:
            let v = variables ?? []
            running = false
            currentAction = nil
            stopTimers()
            if Bool(v[0]) ?? false {
                levelPath.reset()
            }
            runCommonAnimation(.standBy)
            sendCommand(.finish)
            
            liveLog(PlaygroundPage.current.assessmentStatus)
              
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5, execute: {
                if
                  let s = PlaygroundPage.current.assessmentStatus {
                  switch  s {
                  case .pass(message: _):
                      liveLog("passed")
                      self.lessonCompleted()
                  default:
                      liveLog(s)
                      break
                  }
                }
            })
        case .moveBody, .moveRightArm, .moveRightLeg, .moveRightFoot, .moveLeftArm, .moveLeftLeg, .moveLeftFoot:
            guard let v = variables else { onAnimationFinish(); break }
            isEnvironmentReadyToExecuteCommands {
                self.runMoveBodyAnimation(v[0..<6].map{Int8($0)}, beats:v.count > 6 ? Double(v.last!) : nil)
            }
        case .setBpmOfMySong:
            isEnvironmentReadyToExecuteCommands {
                if let v = variables?.first, let i = UInt(v) {
                    self.bpmOfMySong = i
                }
                self.onAnimationFinish()
            }
        default:
            isEnvironmentReadyToExecuteCommands {
                self.runCommonAnimation(action, beats:Double(variables?.last ?? ""))
            }
        }
    }
    
    func sendCommand(_ action:Action, variables:[String]? = nil) {
        #if !APP
            send(Command(action, variables:variables).playgroundValue)
        #endif
    }
    
    func onAnimationFinish() {
        self.hasDetectedNext = levelPath.isCellToMoveAvailableToWalk()
        sendCommand(._notif, variables:["\(self.bpm)", "\(self.music)", "\(self.hasDetectedNext)", "\(levelPath.isFinalCell())", "\(userLesson!.rawValue)"])
        
        if let a = currentAction {
            sendCommand(a, variables: a == .start ? ["\(bpm)", "\(music)"] : nil)
            currentAction = nil
        }
    }
    
    func tryStarting() {
        if !connecting && starting {
            starting = false
            runCommonAnimation(.standBy)
        }
    }
}

extension BaseSceneController: PlaygroundLiveViewMessageHandler {
    //手动开始
    public func liveViewMessageConnectionOpened() {
        liveLog("live opened")
        pageLog("live opened")
        dismissAudioMenu()
        running = true
    }
    
    //手动结束
    public func liveViewMessageConnectionClosed() {
        liveLog("live closed \(running)")
        pageLog("live closed")
        if running {
            levelPath.reset()
            running = false
            currentAction = nil
            stopTimers()
            runCommonAnimation(.standBy)
            sendCommand(._cancel)
        }
    }
    
    public func receive(_ message: PlaygroundValue) {
        liveLog("\(#function) \(#line) = \(message)")
        guard let cmd = Command(message) else {
            return
        }
        if cmd.action == ._log {
            if let arr = cmd.variables, arr.count >= 2 {
                if let n = Int(arr[1]) {
                    log(arr[0], line:n)
                }
            }
        } else {
            if running {
                liveLog("recv act = \(cmd.action.rawValue)")
                onReceive(cmd.action, variables:cmd.variables)
            }
        }
    }
}
