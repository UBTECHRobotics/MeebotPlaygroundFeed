//
//  SceneController+Animation.swift
//  PlaygroundScene
//
//  Created by newman on 17/3/15.
//  Copyright © 2017年 UBTech Inc. All rights reserved.
//

import Foundation
import UIKit
import SceneKit
import PlaygroundSupport
import EndCutscene

func calibrate_step_duration(_ duration:Double) -> Double {
    return max(0.25, min(duration, 10))
}

extension BaseSceneController {
    
    func loadAnimations() {
        //load servo angles
        if let p = Bundle.main.path(forResource: "Angles/servo_angles", ofType: "plist"), let nd = NSDictionary(contentsOfFile: p) as? [String:[[UInt8]]] {
            nd.forEach{
                let fixedMoves: [[UInt8]] = $1.map { originalMoves in
                    return originalMoves.enumerated().map { (index, move) -> UInt8 in
                        let m: UInt8 = (index == 1 || index == 4) ? UInt8( Int(move) +  2 * (120 - Int(move))) : move
                        return m
                    }
                }
                if let a = Action(rawValue:$0) {
                    servoAngles[a] = fixedMoves
                }
            }
        }

        //load animation
        Bundle.main.paths(forResourcesOfType: "plist", inDirectory: "").forEach{
            if let dict  = NSArray(contentsOfFile: $0) as? [[String:[Double]]], let last = $0.components(separatedBy: "/").last, let name = last.components(separatedBy: ".").first, let a = Action(rawValue:name){
                animations[a] = dict
            }
        }
        
        //load correct animations
        let decoder = JSONDecoder()
        jimuAnimations = Bundle.main.paths(forResourcesOfType: "json", inDirectory: "").compactMap {
            guard
                let jsonData = FileManager.default.contents(atPath: $0),
                var animation = try? decoder.decode(AnimationsRoot.self, from: jsonData)
                else { return nil }
            animation.name = String(String($0.split(separator: "/").last ?? "").split(separator: ".").first ?? "")
            return animation
        }
    }
    
    func runCommonAnimation(_ action: Action, beats: Double? = nil) {
        liveLog(#function)
        let actorNode = rootNode?.childNode(withName: ActorNodeName, recursively: true)
        let endPosition = getEndCoordinate(for: action)
        guard isAllowed(position: endPosition) else {
            pageLog("out of maze")
            PlaygroundPage.current.assessmentStatus = .fail(hints: ["Oh no. I can't move there"], solution: nil)
            sendCommand(.finish)
            return
        }
        
        let animation = jimuAnimations.filter { $0.name == action.rawValue }.first
        var speedMultiplier: Double = calibrate_step_duration((beats ?? 1.0))
        guard
            let timeDurations = animation?.timeDurations(),
            let angles = animation?.angles()
            else {
            liveLog("runCommonAnimation ERROR : missing command: \(action)")
            return
        }
        // NOTE: - check for maximum animation duration
        let maxDuration = timeDurations.max() ?? 1.0
        speedMultiplier = maxDuration > 1 ? 5.0 : speedMultiplier
        if let animation = extractAnimation(for: action, speedMultiplier: speedMultiplier) {
            liveLog("previous animations \(rootNode?.animationKeys ?? [])")
            if #available(iOS 11.0, *) {
                rootNode?.removeAnimation(forKey: "animation", blendOutDuration: 0.2)
            } else {
                rootNode?.removeAllAnimations()
            }
            rootNode?.addAnimation(animation, forKey: "animation")
            turnRobotByDegress(action: action, repeatCount: animation.repeatCount)
            var translationDuration = timeDurations
            translationDuration.removeFirst()
            let _ = Timer.scheduledTimer(withTimeInterval: translationDuration.first ?? 0.0, repeats: false, block: { _ in
                SCNTransaction.begin()
                SCNTransaction.animationDuration = translationDuration.reduce(0, +)
                switch action {
                case .moveToLeft, .moveForward, .moveToRight, .moveBackward:
                    actorNode?.position = endPosition
                default: break
                }
                SCNTransaction.commit()
            })
        } else if action == .standBy {
           reset3DModel()
        }
        var index = 1
        var delay: Double = 0
        var animationIndex = 1
        while index < angles.count {
            let timer = Timer.scheduledTimer(withTimeInterval: delay, repeats: false) {[weak self] _ in
                Meebot.shared.setServos(angles[animationIndex], duration: UInt((timeDurations[animationIndex] * 1000) * speedMultiplier))
                animationIndex += 1
                if animationIndex == angles.count {
                    _ = Timer.scheduledTimer(withTimeInterval: timeDurations[animationIndex-1], repeats: false) {[weak self] _ in
                        self?.onAnimationFinish()
                    }
                }
                self?.animationTimeStamp = CFAbsoluteTimeGetCurrent()
            }
            animationTimers.append(timer)
            delay += timeDurations[index] * speedMultiplier
            index += 1
        }
    }
    
    private func turnRobotByDegress(action: Action, repeatCount: Float) {
        if repeatCount <= 0 { return }
        guard let robotNode = rootNode?.childNode(withName: ActorNodeName, recursively: true) else { return }
        var angleForAdding = Float(repeatCount) * 45
        
        if action == .turnRight { angleForAdding = -angleForAdding }
        let finalAngle = roundf(angleForAdding + Float(robotNode.eulerAngles.y * 180.0 / .pi))
        let rotateAction = SCNAction.rotateTo(x: 0, y: CGFloat(finalAngle) * .pi / 180.0, z: 0, duration: TimeInterval(repeatCount * 1.9))
        robotNode.runAction(rotateAction) {
            robotNode.eulerAngles.y = robotNode.eulerAngles.y.truncatingRemainder(dividingBy: 2 * .pi)
        }
    }
    
    private func isAllowed(position: SCNVector3) -> Bool {
        guard
            let gridRoot = scene.gridWorld.gridNode?.rootNode
            else { return false }
        let posInGrid = scene.gridWorld.rootNode.convertPosition(position, to: gridRoot)
        return scene.gridWorld.gridNode?.isValid(position: posInGrid) ?? false
    }
    
    private func getEndCoordinate(for action: Action) -> SCNVector3 {
        guard
            let actorNode = rootNode?.childNode(withName: ActorNodeName, recursively: true)
            else { return SCNVector3Zero }
        
        if action == .moveToLeft || action == .moveForward || action == .moveBackward || action == .moveToRight {
            let actorFacing = scene.gridWorld.actorFacing
            scene.gridWorld.actorCoordinate.setNewPosition(direction: actorFacing, action: action, gridWorld: scene.gridWorld, robotYAngle: actorNode.eulerAngles.y)
            return scene.gridWorld.actorWorldCoordinate
        }
        return actorNode.position
    }
    
    /// Set 3D model node rotations to the initial state (standBy Action)
    private func reset3DModel() {
        if #available(iOS 11.0, *) {
            rootNode?.removeAnimation(forKey: "animation", blendOutDuration: 1.0)
        } else {
            rootNode?.removeAllAnimations()
        }
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 1.0
        for index in 1...6 {
            rootNode?.childNode(withName: "ServoID\(index)", recursively: true)?.removeAllActions()
            rootNode?.childNode(withName: "ServoID\(index)", recursively: true)?.eulerAngles = SCNVector3Zero
        }
        rootNode?.childNode(withName: "Neck", recursively: true)?.removeAllActions()
        rootNode?.childNode(withName: "Neck", recursively: true)?.eulerAngles = SCNVector3Zero
        rootNode?.childNode(withName: "Armature", recursively: true)?.removeAllActions()
        rootNode?.childNode(withName: "Armature", recursively: true)?.position = SCNVector3Zero
        rootNode?.childNode(withName: "Armature", recursively: true)?.eulerAngles = SCNVector3Zero
        SCNTransaction.commit()
    }
    
    func resetModel() {
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 1
        SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        rootNode?.childNode(withName: ActorNodeName, recursively: true)?.position = scene.gridWorld.actorWorldCoordinate
        SCNTransaction.commit()
    }
    
    private func extractAnimation(for action: Action, speedMultiplier: Double) -> CAAnimation? {
        guard let sceneURLs = Bundle.main.urls(forResourcesWithExtension: "scn", subdirectory: "") else { return nil }
        guard let sceneURL: URL = (sceneURLs.filter { $0.relativePath.contains(action.rawValue) }.first) else { return nil }
        let t = SCNReferenceNode(url: sceneURL)
        t?.load()
        guard let animation = t?.allAnimations.first else { return nil }
        animation.speed = animation.speed / Float(speedMultiplier)
        switch action {
            case .turnLeft, .turnRight: animation.repeatCount = 2
            default: animation.repeatCount = 0
        }
        return animation
    }
    
//    private func calculateAngleForOppositeFoot(angle: CGFloat, isLeftLeg: Bool) -> CGFloat {
//        let normilizedAngle = isLeftLeg ? -angle : angle
//        let halfPi = Double.pi / 2
//        let perpendicularDistanceFromServoCenterToFoot = 3.78
//        let distanceFromServoCenterToFootEnd = 5.3
//        let distanceBetweenFeetServoCenters = 7.191
//        let radAngleBetweenFootEndAndPerpendicularToThisFoot = acos(3.78/distanceFromServoCenterToFootEnd)
//        let radAngleBetweenFootEndAndOppositeServoCenter = halfPi + radAngleBetweenFootEndAndPerpendicularToThisFoot - Double(normilizedAngle)
//        let distanceFromFootEndToOppositeServoCenter = sqrt(pow(distanceFromServoCenterToFootEnd, 2) + pow(distanceBetweenFeetServoCenters, 2) - 2 * distanceFromServoCenterToFootEnd * distanceBetweenFeetServoCenters * cos(radAngleBetweenFootEndAndOppositeServoCenter))
//        let radAngleBetweenServoCentersAndFootEndDistance = acos((pow(distanceBetweenFeetServoCenters, 2) + pow(distanceFromFootEndToOppositeServoCenter, 2) - pow(distanceFromServoCenterToFootEnd, 2)) / (2 * distanceBetweenFeetServoCenters * distanceFromFootEndToOppositeServoCenter))
//        let radAngleBetweenOppositeFootEndAndServoCenterPerpendicular = halfPi - radAngleBetweenServoCentersAndFootEndDistance
//        let distanceFromFootEndToOppositesServoCenterPerpendicular = sqrt(pow(perpendicularDistanceFromServoCenterToFoot, 2) + pow(distanceFromFootEndToOppositeServoCenter, 2) - 2 * perpendicularDistanceFromServoCenterToFoot * distanceFromFootEndToOppositeServoCenter * cos(radAngleBetweenOppositeFootEndAndServoCenterPerpendicular))
//        let radAngleBetweenServoCenterPerpendicularAndOppositeFootEndDistance = acos((pow(distanceFromFootEndToOppositesServoCenterPerpendicular, 2) + pow(perpendicularDistanceFromServoCenterToFoot, 2) - pow(distanceFromFootEndToOppositeServoCenter, 2)) / (2 * distanceFromFootEndToOppositesServoCenterPerpendicular * perpendicularDistanceFromServoCenterToFoot))
//        let radAngleForOppositeFoot = radAngleBetweenServoCenterPerpendicularAndOppositeFootEndDistance - halfPi
//        return isLeftLeg ? -CGFloat(radAngleForOppositeFoot) : CGFloat(radAngleForOppositeFoot)
//    }
//
//    func calculateRobotHeight(angle: CGFloat) -> Float {
//        let distanceBetweenFeetServoCenters = 7.191
//        let halfDistanceBetweenFeetServoCenters = Float(distanceBetweenFeetServoCenters / 2.0)
//        return Float(tan(abs(angle))) * halfDistanceBetweenFeetServoCenters
//    }
//
//    private func calculateAngleForOppositeFoot2(angle: CGFloat, isLeftLeg: Bool) -> CGFloat {
//        let normilizedAngle = isLeftLeg ? -angle : angle
//        let doubledPi = Double.pi * 2
//        let halfPi = Double.pi / 2
//        let perpendicularDistanceFromServoCenterToFoot = 3.78
//        let distanceFromServoCenterToFootEnd = 5.3
//        let distanceBetweenFeetServoCenters = 7.191
//
//        let radAngleBetweenFootEndAndPerpendicularToThisFoot = acos(perpendicularDistanceFromServoCenterToFoot/distanceFromServoCenterToFootEnd)
//        let radAngleBetweenFootEndAndOppositeServoCenter = halfPi + radAngleBetweenFootEndAndPerpendicularToThisFoot - Double(normilizedAngle)
//        let distanceFromFootEndToOppositeServoCenter = sqrt(pow(distanceFromServoCenterToFootEnd, 2) + pow(distanceBetweenFeetServoCenters, 2) - 2 * distanceFromServoCenterToFootEnd * distanceBetweenFeetServoCenters * cos(radAngleBetweenFootEndAndOppositeServoCenter))
//        let radAngleBetweenServoCentersAndFootEndDistance = acos((pow(distanceFromServoCenterToFootEnd, 2) + pow(distanceFromFootEndToOppositeServoCenter, 2) - pow(distanceBetweenFeetServoCenters, 2)) / (2 * distanceFromServoCenterToFootEnd * distanceFromFootEndToOppositeServoCenter))
//        let radAngleFromFootEndToOppositeServoCenterToOppositeServoCenterPerpendicular = asin(perpendicularDistanceFromServoCenterToFoot/distanceFromFootEndToOppositeServoCenter)
//        let radAngleFromServoCenterToFootEndToOppositeServoCenterPerpendicular = radAngleFromFootEndToOppositeServoCenterToOppositeServoCenterPerpendicular + radAngleBetweenServoCentersAndFootEndDistance
//        let radAngleFromServoCenterToFootEndToServoCenterPerpendicular = asin(perpendicularDistanceFromServoCenterToFoot/distanceFromServoCenterToFootEnd)
//        let radAngleFromServoCentersToOppositeFootEnd = doubledPi - radAngleBetweenFootEndAndOppositeServoCenter - radAngleFromServoCenterToFootEndToServoCenterPerpendicular - radAngleFromServoCenterToFootEndToOppositeServoCenterPerpendicular
//        let radAngleForOppositeFoot = radAngleFromServoCentersToOppositeFootEnd - radAngleBetweenFootEndAndPerpendicularToThisFoot - halfPi
//        return isLeftLeg ? -CGFloat(radAngleForOppositeFoot) : CGFloat(radAngleForOppositeFoot)
//    }
//
//    private func calculateRobotHeight2(angle: CGFloat) -> Float {
//        let doubledPi = Double.pi * 2
//        let halfPi = Double.pi / 2
//        let perpendicularDistanceFromServoCenterToFoot = 3.78
//        let distanceFromServoCenterToFootEnd = 5.3
//        let halfDistanceBetweenFeetServoCenters = 7.191 / 2
//
//        let radAngleBetweenServoCentersAndOppositeServoCenterPerpendicular = halfPi + Double(angle)
//        let redAngleBetweenSErvoCenterPerpendicularAdnoppositeFootEnd = doubledPi - .pi - radAngleBetweenServoCentersAndOppositeServoCenterPerpendicular
//        let distanceFromCenterOfServoCentersToOppositeServoPerpendicular = sqrt(pow(halfDistanceBetweenFeetServoCenters, 2) + pow(perpendicularDistanceFromServoCenterToFoot, 2) - 2 * halfDistanceBetweenFeetServoCenters * perpendicularDistanceFromServoCenterToFoot * cos(radAngleBetweenServoCentersAndOppositeServoCenterPerpendicular))
//        let radAngleFromOppositeCenterPerpendicularToCenterOfServoCentersToOppositeServoCenter = atan(perpendicularDistanceFromServoCenterToFoot/halfDistanceBetweenFeetServoCenters)
//        let radAngleFromCenterPenperdicularOfServoCentersToOppoisteServoCentralPerpendicular = halfPi - radAngleFromOppositeCenterPerpendicularToCenterOfServoCentersToOppositeServoCenter
//        let radAngleFromCenterOfServoCentersToOppositeServoCentralPerpebdicularToCenterPenperdicularOfServoCenters = .pi - redAngleBetweenSErvoCenterPerpendicularAdnoppositeFootEnd - radAngleFromCenterPenperdicularOfServoCentersToOppoisteServoCentralPerpendicular
//        let distanceOfCenterPenperdicularOfServoCenters = distanceFromCenterOfServoCentersToOppositeServoPerpendicular * sin(radAngleFromCenterOfServoCentersToOppositeServoCentralPerpebdicularToCenterPenperdicularOfServoCenters) / sin(redAngleBetweenSErvoCenterPerpendicularAdnoppositeFootEnd)
//        let finalHeight = distanceOfCenterPenperdicularOfServoCenters - perpendicularDistanceFromServoCenterToFoot
//        return Float(abs(finalHeight))
//    }
    
    private func calculateRobotHeight(angle: CGFloat, servoName: String) -> Float {
        let normalizedAngle = servoName.contains("3") ? -angle : angle
        let perpendicularDistanceFromServoCenterToFoot = 3.78
        let distanceFromServoCenterToFootEnd = 5.3
        let radAngleBetweenFootEndAndPerpendicularToThisFoot = acos(3.78/distanceFromServoCenterToFootEnd)
        
        let firstHeight = cos(abs(Double(normalizedAngle))) * perpendicularDistanceFromServoCenterToFoot
        
        var radAngleBetweenFootEndAndOppositeServoCenter = abs(radAngleBetweenFootEndAndPerpendicularToThisFoot - Double(normalizedAngle))
        let secondHeight = cos(abs(radAngleBetweenFootEndAndOppositeServoCenter)) * distanceFromServoCenterToFootEnd
        
        var oppositeFootAngle = rootNode?.childNode(withName: servoName, recursively: true)?.eulerAngles.z ?? 0
        oppositeFootAngle = servoName.contains("3") ? oppositeFootAngle : -oppositeFootAngle
        
        let thirdHeight = cos(abs(Double(oppositeFootAngle))) * perpendicularDistanceFromServoCenterToFoot
        
        radAngleBetweenFootEndAndOppositeServoCenter = abs(radAngleBetweenFootEndAndPerpendicularToThisFoot - Double(oppositeFootAngle))
        let fourthHeight = cos(abs(radAngleBetweenFootEndAndOppositeServoCenter)) * distanceFromServoCenterToFootEnd
        
        var heightArr = [firstHeight, secondHeight, thirdHeight, fourthHeight]
        heightArr.sort()
        heightArr.reverse()
        
        return Float(heightArr[0] - perpendicularDistanceFromServoCenterToFoot)
    }
    
    func runMoveBodyAnimation(_ angles: [Int8?], beats: Double? = nil) {
        let beats_per_step = beats ?? 0 > 0 ? beats! : 1.0
        let duration_per_step = calibrate_step_duration(beats_per_step * 60 / Double(bpm) * timeScale)
        liveLog("duration_per_step \(duration_per_step)")
        let anglesForRobot: [UInt8?] = angles.enumerated().map { (index, angle) in
            guard let angle = angle else {
                return nil
            }
            // FIXME: - swap left and right arm angles
            // 1 : right arm
            // 4 : left arm
            return UInt8(120 + ( (index == 4 || index == 1) ? -Int(angle) : Int(angle) ) )
        }
        Meebot.shared.setServos(anglesForRobot, duration:UInt(duration_per_step * 1000))
        var acts = [String: SCNAction]()
        for (i, e) in angles.enumerated() {
            if let ee = e {
                let radAngle = CGFloat(ee) * CGFloat(Double.pi / 180)
                let vector = i == 0 || i == 3 ? SCNVector3(0, 1, 0) : SCNVector3(0, 0, 1)
                let rotate = SCNAction.rotateTo(x: CGFloat(vector.x) * radAngle,
                                                 y: CGFloat(vector.y) * radAngle,
                                                 z: CGFloat(vector.z) * radAngle,
                                                 duration: duration_per_step, usesShortestUnitArc: true)
                acts["ServoID\(i+1)"] = rotate
                if i == 2 || i == 5 {
                    let robotHeight = calculateRobotHeight(angle: radAngle, servoName: "ServoID\(i == 5 ? 3 : 6)")
                    let moveAction = SCNAction.move(to: SCNVector3(x: 0, y: robotHeight, z: 0), duration: duration_per_step)
                    acts["Armature"] = moveAction
                } else if i == 4 {
                    acts["Neck"] = SCNAction.rotateTo(x: 0, y: radAngle / 2, z: 0,
                    duration: duration_per_step, usesShortestUnitArc: true)
                }
            }
        }
        //腿没动就是没联动，可以reset以避免3D运行混乱
        if angles[0] == nil && angles[3] == nil {
            if let vs = animations[.standBy]?.first {
                vs.forEach{
                    let move = SCNAction.move(to: SCNVector3($1[0], $1[1], $1[2]), duration: duration_per_step)
                    let rotate = SCNAction.rotateTo(x: CGFloat($1[3] * Double.pi / 180) , y: CGFloat($1[4] * Double.pi / 180), z: CGFloat($1[5] * Double.pi / 180), duration: duration_per_step, usesShortestUnitArc: true)
                    if let r = acts[$0] {
                        acts[$0] = SCNAction.group([move, r])
                    }else{
                        acts[$0] = SCNAction.group([move, rotate])
                    }
                }
            }
        }
        acts.forEach{
            if let node = rootNode?.childNode(withName: $0, recursively: true) {
                node.removeAllActions()
                node.runAction($1)
            }
        }
        let time = CFAbsoluteTimeGetCurrent()
        liveLog("duration moveBody \(time - animationTimeStamp)")
        animationTimeStamp = time
        stopTimers()
        animationTimers.append(Timer.scheduledTimer(withTimeInterval: duration_per_step, repeats: false) {[weak self] _ in
            self?.onAnimationFinish()
        })
        animationTimers.first?.tolerance = 0
    }
}
