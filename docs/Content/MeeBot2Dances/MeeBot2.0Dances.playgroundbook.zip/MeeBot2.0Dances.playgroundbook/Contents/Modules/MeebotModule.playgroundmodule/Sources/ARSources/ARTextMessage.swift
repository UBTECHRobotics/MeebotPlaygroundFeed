////
//  Book_Sources
//
//  Created by George Michael on 12/12/2019
//

import Foundation

public enum ARTextMessage: String {
    case pointCameraToTheRobot
    case pointCameraToFlatSurface
    case objectDetected
    case slowDown
    case moveBackAndForthToFindSurface
    case moveBackAndForthToFindRobot
    case noCamera
    case resuming
    case cantFindRobot
    
    public var text: String {
        return NSLocalizedString(self.rawValue, comment: "")
    }
}
