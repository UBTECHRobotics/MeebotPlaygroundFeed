////
//  LiveViewTestApp
//
//  Created by George Michael on 28/01/2020
//

import Foundation
import SceneKit

class GridNode {
    
    static let GridNodeName = "GridNode"
    var availableCoordinates = [Coordinate]()
    
    var rootNode: SCNNode?
    
    var allNodes: [SCNNode] {
           return rootNode?.childNodes ?? []
       }
    
    init(with node : SCNNode) {
        rootNode = node.childNode(withName: GridNode.GridNodeName, recursively: true)
        availableCoordinates = allNodes.map { Coordinate($0.position) }
    }
    
    func isValid(position: SCNVector3) -> Bool {
        let coordinate = Coordinate(position)
        return availableCoordinates.contains(coordinate)
    }
}
