//
//  AssessmentManager.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

public var assessmentManager:AssessmentManager?

public class AssessmentManager:NSObject {
    var assessment:([Command], Bool?)->PlaygroundPage.AssessmentStatus
    public init(_ assessment:@escaping ([Command], Bool?)->PlaygroundPage.AssessmentStatus){
        self.assessment = assessment
        super.init()
    }
    public func updateAssessment(_ commands:[Command], successful:Bool? = nil) {
        liveLog("\(#function) \(#line) = \(commands)")
        PlaygroundPage.current.assessmentStatus = assessment(commands, successful)
    }
}

extension PlaygroundPage.AssessmentStatus {
    public static func ==(first: PlaygroundPage.AssessmentStatus, second: PlaygroundPage.AssessmentStatus) -> Bool {
        switch (first, second) {
        case (.fail(hints: _, solution: _), .fail(hints: _, solution: _)): return true
        default: return false
        }
    }
    
    public static func ===(first: PlaygroundPage.AssessmentStatus, second: PlaygroundPage.AssessmentStatus) -> Bool {
        switch (first, second) {
        case let (.pass(message: firstMessage), .pass(message: secondMessage)):
            return firstMessage == secondMessage
        case let (.fail(hints: firstHints, solution: firstSolution), .fail(hints: secondHints, solution: secondSolution)):
            return firstHints == secondHints && firstSolution == secondSolution
        default: return false
        }
    }
}
