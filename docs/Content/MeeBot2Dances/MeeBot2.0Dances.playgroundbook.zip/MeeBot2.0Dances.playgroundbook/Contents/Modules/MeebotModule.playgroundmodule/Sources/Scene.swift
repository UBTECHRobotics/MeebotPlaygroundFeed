//
//  Scene.swift
//  JimuPlaygroundBook
//
//  Created by hechao on 2016/12/26.
//  Copyright © 2016年 UBTech Inc. All rights reserved.
//

import UIKit
import SceneKit

final class Scene: NSObject {
    // MARK: Properties
    private let source: SCNSceneSource
    var environmentLight: SCNMaterialProperty?
    
    lazy var scnScene: SCNScene = {
        var scene = SCNScene()
        do {
            let sourceScene = try self.source.scene()
            
            let stageNode = sourceScene.rootNode.childNode(withName: GridNodeName, recursively: false)
            let cameraHandleNode = sourceScene.rootNode.childNode(withName: CameraHandleName, recursively: false)
            
            stageNode?.removeFromParentNode()
            cameraHandleNode?.removeFromParentNode()
            
            scene.rootNode.addChildNode(stageNode!)
            scene.rootNode.addChildNode(cameraHandleNode!)
            
            sourceScene.rootNode.name = GridNodeName
            scene.rootNode.name = RootNodeName
        } catch {
            fatalError("Failed to Load Scene.\n\(error)")
        }
        // remove stage root node and then reload the stage root node
        scene.rootNode.childNode(withName: GridNodeName, recursively: false)?.removeFromParentNode()
        scene.rootNode.addChildNode(self.gridWorld.rootNode.clone())
        return scene
    }()
    
    var rootNode: SCNNode {
        return scnScene.rootNode
    }
    
    let gridWorld: GridWorld
    
    /// Initialize with an ".scn" scene.
    convenience init?(named sceneName: String, coordinate: Coordinate = .init(column: 0, row: 0), facing: Direction = .south) throws {
        let path = "WorldResources.scnassets/_Scenes/" + sceneName
        let sURL = Bundle.main.url(forResource: path, withExtension: "scn") ?? Bundle.main.url(forResource: path, withExtension: "dae")
        guard let source = SCNSceneSource(url: sURL!, options: nil) else {
            throw GridLoadingError.invalidSceneName(sceneName)
        }
        try self.init(source: source, coordinate: coordinate, facing: facing)
    }
    
    init?(source: SCNSceneSource, coordinate: Coordinate, facing: Direction) throws {
        self.source = source
        var sourceRootNode: SCNNode = SCNNode()
        do {
            let sceneSource = try source.scene(options: nil)
            sourceRootNode = sceneSource.rootNode
            environmentLight = sceneSource.lightingEnvironment
        } catch { }
        pageLog(sourceRootNode.name)
        guard let baseGridNode = sourceRootNode.childNode(withName: GridNodeName, recursively: true) else {
            throw GridLoadingError.missingGridNode(GridNodeName)
        }
        gridWorld = GridWorld(node: baseGridNode, actorCoordinate: coordinate, facing: facing)
        super.init()
    }
    
    // MARK: Initial
    init(world: GridWorld) {
        gridWorld = world
        // load template scene.
        let templatePath = ""
        let templateURL = Bundle.main.url(forResource: templatePath, withExtension: "dae")!
        source = SCNSceneSource(url: templateURL, options: nil)!
    }
}


