//
//  AudioMenuActionHandler.swift
//  LiveView
//
//  Created by Liz Chaddock on 6/21/17.
//  Copyright © 2017 Liz Chaddock. All rights reserved.
//

import Foundation
import MediaPlayer

class AudioMenuActionHandler : NSObject {
    var tableViewController : UITableViewController
    var menuDelegate : AudioMenuControllerDelegate
    weak var dataSource : AudioMenuDataSource?

    init(with tableViewController: UITableViewController, menuDelegate: AudioMenuControllerDelegate) {
        self.tableViewController = tableViewController
        self.menuDelegate = menuDelegate
        super.init()
    }
    
    func handleCheckedCellSelection(model: Any, index: Int) {
        Persisted.backgroudAudioSelectedIndex = index
        
        let newRow = index
        let oldRow = (dataSource?.lastIndexPath != nil) ? dataSource?.lastIndexPath?.row : -1
        if newRow != oldRow {
            dataSource?.setTableViewCellSelected(index: index)
        }
        playSongAt(index: index)
    }
    
    func handleAddMusicCellSelection(model: Any, index: Int) {
        addMusicFromLib()
    }
    
    func playSongAt(index: Int) {
        self.menuDelegate.playSongAt(index: index)
    }
    
    func enableAudioMenuSelection(_ isEnabled: Bool) {
        self.dataSource?.updateSwitchCellModel(enabled: isEnabled)
        self.menuDelegate.enableAudioMenuSelect(isEnabled)
    }
    
    func addMusicFromLib() {
        if MPMediaLibrary.authorizationStatus() == .authorized {
            // success:
            self.showMediaPickerController()
        } else {
            MPMediaLibrary.requestAuthorization({ (status) in
                switch status {
                case .authorized:
                    self.showMediaPickerController()
                case .denied: fallthrough
                case .notDetermined: fallthrough
                case .restricted: break
                @unknown default:
                    break
                }
            })
        }
    }
    
    // show Media picker
    func showMediaPickerController() {
        let mpc = MPMediaPickerController(mediaTypes: .anyAudio)
        mpc.delegate = self.tableViewController as? MPMediaPickerControllerDelegate
        //mpc.prompt = "Please select a music"
        mpc.allowsPickingMultipleItems = false
        self.tableViewController.present(mpc, animated: true, completion: nil)
    }

}
