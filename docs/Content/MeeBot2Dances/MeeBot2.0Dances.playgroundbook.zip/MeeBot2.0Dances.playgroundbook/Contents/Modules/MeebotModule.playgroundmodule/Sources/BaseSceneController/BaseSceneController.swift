////
//  Book_Sources
//
//  Created by George Michael on 10/12/2019
//

import UIKit
import SceneKit
import AVFoundation
import PlaygroundSupport
import MediaPlayer

import CoreBluetooth
import PlaygroundBluetooth


class BaseSceneController: UIViewController {
    // MARK: Properties
    let scene: Scene
    
    var hasDetectedNext: Bool = false
    
    /// root node
    var rootNode: SCNNode? { nil }
    
    /// lesson
    var userLesson: Lesson?
    var running = false
    
    var isEnvironmentReadyToExecuteCommands: ( @escaping () -> Void ) -> () = { _ in }
    
    var playgroundBluetoothConnectionView: PlaygroundBluetoothConnectionView!
    lazy var connecting = false
    lazy var starting = false
    
    // Persisted data
    var isAudioOpen = Persisted.isBackgroundAudioEnabled
    
    let audioButton = UIButton(type: .custom)
    
    // loadingQueue
    let loadingQueue = OperationQueue()
    
    // Audio menu
    var audioMenu: AudioMenuController?
    
    /// audioPlayer
    var audioPlayer: AVAudioPlayer?
    var isPlaying: Bool?
    lazy var loadingView = UIImageView(frame:CGRect(x:0, y:0, width:100, height:100))
    let musicPlayer = MPMusicPlayerController.applicationMusicPlayer
    
    var currentAction: Action?
    
    // song file name
//    lazy var buildInSongArray = [musicIntro, musicBitBitLoop]
    lazy var songArray = [MusicSong.Intro.rawValue, MusicSong.Bit_Bit_Loop.rawValue]
    lazy var curentBPM: UInt = 120
    var curentMusic: String?
    var bpmOfMySong: UInt?
    
    lazy var servoAngles = [Action:[[UInt8]]]()
    lazy var animations = [Action:[[String:[Double]]]]()
    lazy var jimuAnimations = [AnimationsRoot]()
    var animationTimers: [Timer] = []
    var animationTimeStamp = 0.0
    
    // logs
    lazy var logView = UITextView(frame:CGRect(x:0,y:0,width:250,height:450))
    let logDateFormat = DateFormatter()
    
    init(scene: Scene, _ lesson: Lesson = .lessonNone) {
      self.scene = scene
      super.init(nibName: nil, bundle: nil)
      userLesson = lesson
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Config log format
        logDateFormat.dateFormat = "ss:SSS"
        addViews()
        Meebot.shared.delegate = self
        playgroundBluetoothConnectionView = PlaygroundBluetoothConnectionView(centralManager: Meebot.shared.getCentralManager())
        playgroundBluetoothConnectionView.delegate = self
        playgroundBluetoothConnectionView.dataSource = self
        // Controls
        addControlButtons()
        view.addSubview(loadingView)
        loadingView.image = UIImage(named: "big_spin")
        loadingView.isUserInteractionEnabled = false
        let ca = CABasicAnimation(keyPath: "transform.rotation.z")
        ca.toValue = Double.pi * 2
        ca.repeatCount = HUGE
        ca.duration = 1
        loadingView.layer.add(ca, forKey: "rotation")
        loadingView.isHidden = true
        lessonConfig(lesson:userLesson!)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        loadAnimations()
    }
    
    // Layout
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        loadingView.center = view.center
    }
    
    // MARK: Internal Methods
    
    func addViews() {
        // Debug logView
        if MACRO_DEBUG {
            self.view.addSubview(logView)
            logView.scrollsToTop = true
            logView.textColor = .red
            logView.backgroundColor = .lightGray
            logView.alpha = 0.8
            logView.isHidden = !MACRO_DEBUG
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
         super.viewDidDisappear(animated)
         NotificationCenter.default.removeObserver(self)
     }
     
     override func viewWillAppear(_ animated: Bool) {
         NotificationCenter.default.addObserver(self, selector: #selector(applicationDidEnterBackground), name: UIApplication.didEnterBackgroundNotification, object: nil)
         NotificationCenter.default.addObserver(self, selector: #selector(applicationWillEnterForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
     }
    
    /// Stop all animation timer
    func stopTimers() {
        animationTimers.forEach { $0.invalidate() }
        animationTimers.removeAll()
    }
     
     @objc private func applicationDidEnterBackground() {
         pauseAudioIfAppEnterBackground()
     }
     
     @objc private func applicationWillEnterForeground() {
         lessonConfig(lesson: userLesson!)
     }
    
    // MARK: Lesson configurations for each lesson
      
    func lessonConfig(lesson: Lesson) {
        rotateSkybox()
        let skyTexturesPath = "WorldResources.scnassets/_Scenes/ComponentsForLevels/Skybox/Textures/"
        var skyboxImage: UIImage? = nil
        switch lesson {
            case .lesson1:
                skyboxImage = UIImage(named: skyTexturesPath + "skybox-midday_emi_1k.png")
                showControlButton(show: false)
                scene.environmentLight?.contents = UIImage(named: skyTexturesPath + "day-cyan_environment.exr")
                scene.environmentLight?.intensity = 1.5
                songArray = [MusicSong.Lesson1_2Background.rawValue]
                playAudioIfAudioIsOpen()
            case .lesson2_1:
                skyboxImage = UIImage(named: skyTexturesPath + "skybox-evening_emi_1k.png")
                showControlButton(show: false)
                scene.environmentLight?.contents = UIImage(named: skyTexturesPath + "sunset_environment.exr")
                scene.environmentLight?.intensity = 2.5
                songArray = [MusicSong.Lesson1_2Background.rawValue]
            case .lesson3:
                skyboxImage = UIImage(named: skyTexturesPath + "skybox-evening_emi_1k.png")
                scene.rootNode.childNode(withName: "Drums", recursively: true)?.isHidden = true
                scene.rootNode.childNode(withName: "3DAudience", recursively: true)?.isHidden = true
                scene.rootNode.childNode(withName: "NightLights", recursively: true)?.isHidden = true
                scene.rootNode.childNode(withName: "EveningLights", recursively: true)?.isHidden = false
                scene.rootNode.childNode(withName: "dance_floor", recursively: true)?.geometry?.firstMaterial?.emission.intensity = 0.25
                scene.environmentLight?.contents = UIImage(named: skyTexturesPath + "sunset_environment.exr")
                scene.environmentLight?.intensity = 2
                showControlButton(show: false)
                self.isAudioOpen = false
            case .lesson4:
                skyboxImage = UIImage(named: skyTexturesPath + "skybox-night_emi_1k.png")
                setupMeebotAudienceJumping()
                scene.rootNode.childNode(withName: "Drums", recursively: true)?.isHidden = false
                scene.rootNode.childNode(withName: "3DAudience", recursively: true)?.isHidden = false
                scene.rootNode.childNode(withName: "NightLights", recursively: true)?.isHidden = false
                scene.rootNode.childNode(withName: "EveningLights", recursively: true)?.isHidden = true
                scene.environmentLight?.contents = UIImage(named: skyTexturesPath + "night_environment.exr")
                scene.environmentLight?.intensity = 2
                setupDanceFloorShader()
                showControlButton(show: true)
                playAudioIfAudioIsOpen()
            case .lesson5:
                skyboxImage = UIImage(named: skyTexturesPath + "skybox-night_emi_1k.png")
                scene.environmentLight?.contents = UIImage(named: skyTexturesPath + "night_environment.exr")
                scene.environmentLight?.intensity = 3
                showControlButton(show: false)
                songArray = [MusicSong.Lesson5Background.rawValue]
            case .lesson6, .lesson7, .lesson8, .lesson9:
                showControlButton(show: true)
                playAudioIfAudioIsOpen()
            default:
                break
        }
        scene.rootNode.childNode(withName: "skybox", recursively: true)?.geometry?.firstMaterial?.emission.contents = skyboxImage
    }
    
    func rotateSkybox() {
        let skybox = scene.rootNode.childNode(withName: "skybox", recursively: true)
        let rotateAction = SCNAction.rotateBy(x: 0, y: .pi, z: 0, duration: 72)
        skybox?.removeAllActions()
        skybox?.runAction(SCNAction.repeatForever(rotateAction))
    }
    
    func setupDanceFloorShader() {
        let surfaceShader = """
        float s = u_time * -0.2;
        float3 c = _surface.emission.rgb;
        float4 K = float4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
        float4 p = mix(float4(c.bg, K.wz), float4(c.gb, K.xy), step(c.b, c.g));
        float4 q = mix(float4(p.xyw, c.r), float4(c.r, p.yzx), step(p.x, c.r));

        float d = q.x - min(q.w, q.y);
        float e = 1.0e-10;
        float3 res = float3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
        res.x += s;

        float4 K1 = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
        float3 p1 = abs(fract(res.xxx + K1.xyz) * 6.0 - K1.www);
        _surface.emission.rgb = res.z * mix(K1.xxx, clamp(p1 - K1.xxx, 0.0, 1.0), res.y);
        """
        
        scene.rootNode.childNode(withName: "dance_floor", recursively: true)?.geometry?.firstMaterial?.shaderModifiers = [.surface: surfaceShader]
    }
    
    func setupMeebotAudienceJumping() {
        for node in scene.rootNode.childNode(withName: "3DAudience", recursively: true)!.childNodes {
            let y = CGFloat.random(in: 3.5 ... 5)
            let duration = Double.random(in: 0.15 ... 0.21)
            let actionUp = SCNAction.moveBy(x: 0, y: y, z: 0, duration: duration)
            let actionDown = SCNAction.moveBy(x: 0, y: -y, z: 0, duration: duration)
            let animationSequence = SCNAction.sequence([actionUp, actionDown])
            let repeatForever = SCNAction.repeatForever(animationSequence)
            node.runAction(repeatForever)
        }
    }
    
    func lessonCompleted() {
        pageLog("base completed")
    }
    
    // MARK: Custom Actions
    func announce(speakableDescription: String) {
        UIAccessibility.post(notification: UIAccessibility.Notification.announcement, argument: speakableDescription)
    }
    
    required init(coder aDecoder: NSCoder) {
        fatalError("This method has not been implemented.")
    }
    
    /// Debug log
    func log(_ log:String, line:Int) {
        logView.text = "\(logView.text ?? "")\n\(logDateFormat.string(from: Date())) \(line): \(log)"
        NSLog("\(line) \(log)")
    }
    
    // MARK: Node
    func getRootNodeWithSceneName(sceneName: String) -> SCNNode {
        var node = SCNNode()
        
        let path = "WorldResources.scnassets/_Scenes/" + sceneName
        guard let sceneURL = Bundle.main.url(forResource: path, withExtension: "scn"),
            let source = SCNSceneSource(url: sceneURL, options: nil) else {
                return node
        }
        do {
            let sourceScene = try source.scene()
            node = sourceScene.rootNode
        }
        catch {
            fatalError("Failed to Load Scene.\n \(error)")
        }
        
        return node.clone()
    }
}

