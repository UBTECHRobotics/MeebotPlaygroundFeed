//
//  CommandQueue.swift
//  JimuPlaygroundBook
//
//  Created by frank on 2016/12/30.
//  Copyright © 2016年 UBTech Inc. All rights reserved.
//

import Foundation
import PlaygroundSupport

public var commandManager: CommandManager?

/**
 A queue which all commands are added so that top level code always
 executers in order, one command at a time.
 */

public class CommandManager: NSObject {
    
    var running = false //执行start()时变true，执行finish()或者liveView取消时变false
    var busy = false    //普通指令发出后标记为true，收到回包后标记为false
    var moveBodyCommand:Command?
    lazy var commands = [Command]()
    public var hasDetectedBlue: Bool = true
    public var isFinalCell: Bool = true
    var userLesson: Lesson! = .lessonNone
    
    //开始执行代码
    public func start(){
        hasDetectedBlue = true
        isFinalCell = true
        running = true
        busy = false
        commands.removeAll()
        liveLog("\(#function) \(#line) = start")
        sendCommand(.start)
    }
    //代码执行完毕
    public func finish() {
        liveLog("\(#function) \(#line) = finish")
        let parsedText = PlaygroundPage.current.text.components(separatedBy: "//#-editable-code")[1].components(separatedBy: "//#-end-editable-code")[0]
        let allLines = parsedText.split(separator: "\n")
        let nonEmptyLines = allLines.filter { (substring) -> Bool in
            return !String(substring).isEmpty
        }
        if userLesson == .lesson5 {
            assessmentManager?.updateAssessment(commands, successful: nonEmptyLines.count <= 14 && isFinalCell)
        } else {
            assessmentManager?.updateAssessment(commands, successful: isFinalCell)
        }
        sendCommand(.finish, variables: ["\(PlaygroundPage.current.assessmentStatus! == .fail(hints: [], solution: nil))"])
    }
    
    public func sendCommand(_ action:Action, variables:[String]? = nil) {
        if userLesson == .lesson5 && commands.count == 31 && action != .finish { finish(); return }
        pageLog("SENDCOMMAND: \(action), running: \(running)")
        if let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy {
            pageLog("SENDING: \(action)")
            if !action.isControl {
                if running {
                    var cmd: Command?
                    if moveBodyCommand != nil {
                        switch action {
                        case .moveBody, .moveRightArm, .moveRightLeg, .moveRightFoot, .moveLeftArm, .moveLeftLeg, .moveLeftFoot:
                            for (i, e) in variables!.enumerated() {
                                if e != "nil" {
                                    moveBodyCommand?.variables?[i] = e
                                }
                            }
                        case .endMoveBody:
                            cmd = moveBodyCommand
                            moveBodyCommand = nil
                        default: break
                        }
                    }else if action == .beginMoveBody {
                        moveBodyCommand = Command(.moveBody, variables:["nil", "nil", "nil", "nil", "nil", "nil", variables!.first!])
                    }else {
                        cmd = Command(action, variables:variables)
                    }
                    if let c = cmd {
                        proxy.send(c.playgroundValue)
                        busy = true
                        commands.append(c)
                        pageLog("before runloop \(c.action)")
                        while running && busy{
                            RunLoop.main.run(mode: .default, before: Date(timeIntervalSinceNow: 0.02))
                        }
                        pageLog("after runloop \(c.action)")
                    }
                }
            }else if action != ._log{
                pageLog("SENDING: \(action)")
                proxy.send(Command(action, variables:variables).playgroundValue)
            }
        }
    }
    
    public func onReceive(_ cmd:Command){
        pageLog("onReceive: \(cmd.action.hashValue)")
        switch cmd.action {
        case .start:
            if let arr = cmd.variables {
                userLesson = Lesson(rawValue: arr[0]) ?? .lessonNone
            }
        case .finish:
            running = false
            commands.removeAll()
            PlaygroundPage.current.finishExecution()
        case ._notif:
            if let arr = cmd.variables {
                updateValues(arr)
            }
        case ._cancel:
            running = false
            PlaygroundPage.current.finishExecution()
        default:
            break
        }
        if !cmd.isControl {
            if running {
                busy = false
            }
        }
    }
    
    public func log(_ log:String, line:Int){
        if let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy {
            proxy.send(Command(._log, variables:[log, "\(line)"]).playgroundValue)
        }
    }
}

extension CommandManager{
    func updateValues(_ values:[String]) {
        if values.count >= 2, let bpm = Int(values[0]) {
            BPMofCurrentMusic = bpm
            currentMusic = stringFromString(values[1])
            if values.count > 2 {
                self.hasDetectedBlue = Bool(values[2]) ?? false
                self.isFinalCell = Bool(values[3]) ?? false
                self.userLesson = Lesson(rawValue: values[4]) ?? .lessonNone
                liveLog("!!!!!NEW VALUE!!!!!! \(hasDetectedBlue)")
            }
            pageLog("\(BPMofCurrentMusic)  \(String(describing: currentMusic))")
        }
    }
}

extension CommandManager:PlaygroundRemoteLiveViewProxyDelegate{
    
    public func remoteLiveViewProxyConnectionClosed(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy) {
        pageLog("page close")
        PlaygroundPage.current.finishExecution()
    }
    
    public func remoteLiveViewProxy(_ remoteLiveViewProxy: PlaygroundRemoteLiveViewProxy, received message: PlaygroundValue) {
        pageLog("remoteLiveViewProxy: \(message)")
        guard let cmd = Command(message) else {
            pageLog("ERROR!!!")
            return
        }
        pageLog("recv act = \(cmd.action ?? "")")
        onReceive(cmd)
    }
}
