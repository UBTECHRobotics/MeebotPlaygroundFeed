////
//  Book_Sources
//
//  Created by George Michael on 11/12/2019
//

import Foundation
import SceneKit
import ARKit

class DetectedObject: SCNNode {
    let referenceObject: ARReferenceObject
    private var actorNode: SCNNode = SCNNode()
    
    init(referenceObject: ARReferenceObject, robotNode: SCNNode) {
        self.referenceObject = referenceObject
        actorNode = robotNode
        actorNode.name = ActorNodeName
        super.init()
        isHidden = true
    }
    
    func set(scene: Scene?, stageNode: SCNNode, lesson: Lesson?) {
        guard let scene = scene else { return }
        stageNode.scale = SCNVector3(x: 0.01, y: 0.01, z: 0.01)
        addChildNode(stageNode)
        stageNode.addChildNode(actorNode)
        actorNode.position = scene.gridWorld.actorWorldCoordinate
    }

    func updateVisualization(newTransform: float4x4) {
        guard isHidden else { return }
        isHidden = false
        simdTransform = newTransform
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
