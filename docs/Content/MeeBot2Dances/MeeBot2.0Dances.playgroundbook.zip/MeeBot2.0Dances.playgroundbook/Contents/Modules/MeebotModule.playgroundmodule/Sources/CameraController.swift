// 
//  CameraController.swift
//
//  Copyright (c) 2016 Apple Inc. All Rights Reserved.
//
import SceneKit
import UIKit

final class CameraController {
    // MARK: Types
    static let absoluteFovMax = 70.0
    
    // MARK: Properties
    
    unowned let scnView: SCNView
    
    /// The lowest yFov angle the camera is allowed to reach when zooming (most zoom).
    let minYFov: Double
    
    /// The largest yFov angle the camera is allowed to reach when zooming (least zoom).
    let maxYFov: Double
    
    let rootHandle = SCNNode()
    
    let camera: SCNCamera
    
    let cameraNode: SCNNode
    
    let orignialFOVy: Double

    let originalRotation: SCNVector4
    
    let originalCameraTransform: SCNMatrix4
    
    var trackball: Trackball
    
    var currentFOVy = 0.0

    // MARK: Initialization
 
    /// Registers for camera gesture recognizers.
    init?(view: SCNView, facing: Direction = .south) {
        guard let scene = view.scene else { return nil }
        guard let cameraHandle = scene.rootNode.childNode(withName: CameraHandleName, recursively: true) else { return nil }
        guard let cameraNode = scene.rootNode.childNode(withName: CameraNodeName, recursively: true) else { return nil }
        
        self.scnView = view
        self.cameraNode = cameraNode
        self.camera = cameraNode.camera!
        
        // Set the minimum and maximum FOV based on the original camera Fov.
        let fov = Double(camera.fieldOfView)
        minYFov = fov * 0.5
        
        // The maximum should be constrained the the `absoluteFovMax` or the camera's initial Fov.
        let upperLimit = max(fov, CameraController.absoluteFovMax)
        maxYFov = upperLimit
        
        rootHandle.name = CameraHandleName
        scene.rootNode.addChildNode(rootHandle)
        
        // Put the camera into the rootHandle's coordinate system
        cameraNode.transform = cameraHandle.convertTransform(cameraNode.transform, to: rootHandle)
        
        // Reparent the camera under the normalized `rootHandle`.
        cameraNode.removeFromParentNode()
        rootHandle.addChildNode(cameraNode)
        cameraHandle.removeFromParentNode()
        
        // BIG PICTURE:
        // pull the y axis rotation out of the camera
        // move the camera to zero degrees around the y axis
        // apply the y rotation to the rootHandle
        
        // grab the position
        var position = cameraNode.position
        // project it into the x/z plane
        position.y = 0.0
        // find the angle
        let yRotation = atan2(position.x, position.z)
        
        // move the camera to the zero rotation spot by applying a negative y rotation
        cameraNode.transform = SCNMatrix4Mult(cameraNode.transform, SCNMatrix4MakeRotation(yRotation, 0.0, -1.0, 0.0))
        
        // rotate the rootHandle to the proper y rotation
        rootHandle.eulerAngles.y = yRotation + facing.radians
        
        let radius = cameraNode.position.length()
        trackball = Trackball(center: scene.rootNode.position, radius: -radius, multiplier: 6.0, inRect: scnView.bounds, transform: rootHandle.transform)
        
        // Save the initial camera information.
        orignialFOVy = fov
        originalCameraTransform = cameraNode.transform
        originalRotation = rootHandle.rotation
        
        self.registerCameraGestureRecognizers()
    }
    
    // MARK: Gesture Recognizers

    func registerCameraGestureRecognizers() {
        scnView.isUserInteractionEnabled = true
        
        let doubleTapGesture = UITapGestureRecognizer(target: self, action: #selector(resetCameraAction(_:)))
        doubleTapGesture.numberOfTapsRequired = 2
        scnView.addGestureRecognizer(doubleTapGesture)
        
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(panCameraAction(_:)))
        scnView.addGestureRecognizer(panGesture)
        
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(zoomCameraAction(_:)))
        scnView.addGestureRecognizer(pinchGesture)
    }

    func zoomCamera(toYFov fov: Double, duration: Double = 1.0, completionHandler: (() -> Void)? = nil) {
        guard let camera = cameraNode.camera else { return }
        SCNTransaction.begin()
        SCNTransaction.animationDuration = duration
        camera.fieldOfView = CGFloat(max(min(fov, maxYFov), minYFov))
        SCNTransaction.completionBlock = completionHandler
        SCNTransaction.commit()
    }

    func resetCamera(duration: CFTimeInterval = 0.75) {
        SCNTransaction.begin()
        SCNTransaction.animationDuration = duration
        SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
        camera.fieldOfView = CGFloat(orignialFOVy)
        // Reset the handle.
        rootHandle.position.y = 0
        cameraNode.transform = originalCameraTransform
        SCNTransaction.commit()
        let delta = (originalRotation.y * originalRotation.w) - (rootHandle.rotation.y * rootHandle.rotation.w)
        let yRotation = SCNAction.rotate(by: CGFloat(delta), around: SCNVector3(0, 1, 0), duration: duration)
        yRotation.timingMode = .easeInEaseOut
        rootHandle.runAction(yRotation) {
            self.trackball.transform = self.rootHandle.transform
        }
    }
    
    // MARK: Gesture Recognizers
    
    @objc func panCameraAction(_ recognizer: UIPanGestureRecognizer) {
        switch recognizer.state {
        case .began:
            trackball.startingPoint = recognizer.location(in: self.scnView)
        case .changed:
            let matrix = trackball.transformFor(recognizer.location(in: self.scnView))
            SCNTransaction.begin()
            SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
            rootHandle.transform = matrix
            SCNTransaction.commit()
        case .ended:
            let matrix = trackball.transformFor(recognizer.location(in: self.scnView))
            SCNTransaction.begin()
            SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
            rootHandle.transform = matrix
            SCNTransaction.commit()
            trackball.finish(recognizer.location(in: self.scnView))
        default:
            break
        }
    }
    
    @objc func zoomCameraAction(_ recognizer: UIPinchGestureRecognizer) {
        liveLog(#function)
        guard let camera = cameraNode.camera else { return }
        
        switch recognizer.state {
        case .began:
            currentFOVy = Double(camera.fieldOfView)
        case .changed:
            let factor = Double(recognizer.scale)
            let yFov = currentFOVy / factor
            // make sure the scale is reset so if we change directions after
            // zooming past the yFOV we reverse the scale
            if yFov > maxYFov {
                let scale = yFov / maxYFov
                recognizer.scale = CGFloat(factor * scale)
            }
            if yFov < minYFov {
                let scale = yFov / minYFov
                recognizer.scale = CGFloat(factor * scale)
            }
            // zoomCamera clips yFov to between minYFov and maxYFov
            zoomCamera(toYFov: yFov, duration: 0.0)
        default:
            break
        }
    }
    
    @objc func resetCameraAction(_: UITapGestureRecognizer) {
        liveLog(#function)
        resetCamera()
    }
}
