////
//  LiveViewTestApp
//
//  Created by George Michael on 23/01/2020
//

import UIKit
import CutscenesBase

@objc(HelloMeebotViewController)
class HelloMeebotViewController: UIViewController {
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        loadInitialValues()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        UIView.animate(withDuration: 0.5, delay: 0.5, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.textField.alpha = 1
            self.textField.transform = .identity
        })
        UIView.animate(withDuration: 0.5, delay: 0.6, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.robotImageView.alpha = 1
            self.robotImageView.transform = .identity
        })
        UIView.animate(withDuration: 0.5, delay: 0.75, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseInOut, animations: {
            self.hiImageView.alpha = 1
            self.hiImageView.transform = .identity
        })
    }
    
    @IBOutlet weak var hiImageView: UIImageView!
    @IBOutlet weak var textField: UILabel!
    @IBOutlet weak var robotImageView: UIImageView!
    
    private func loadInitialValues() {
        textField.text = NSLocalizedString("cutsceneFirstPage", comment: "")
        [hiImageView, textField, robotImageView].forEach { $0?.alpha = 0 }
        textField.transform = CGAffineTransform(translationX: 0, y: 15)
        robotImageView.transform = CGAffineTransform(translationX: 0, y: 45)
        hiImageView.transform = CGAffineTransform(translationX: 55, y: 55)
    }
}
