////
//  LiveViewTestApp
//
//  Created by George Michael on 29/01/2020
//

import Foundation
import SceneKit

@objc(IntroPage4SceneViewController)
class IntroPage4SceneViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var sceneView: SCNView!
    
    let camera = SCNCamera()
    let cameraNode = SCNNode()
    var robotNode = SCNNode()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = NSLocalizedString("cutsceneFourthScene", comment: "")
        titleLabel.alpha = 0
        titleLabel.transform = CGAffineTransform(translationX: 0, y: -45)
        sceneView.alpha = 0
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setupScene()
        loadIslandScene()
        UIView.animate(withDuration: 0.5, delay: 0.5, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.titleLabel.alpha = 1
            self.titleLabel.transform = .identity
        })
        UIView.animate(withDuration: 0.5, delay: 1.0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.sceneView.alpha = 1
        })
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            guard let anim = self.extractAnimation() else { return }
            self.robotNode.addAnimation(anim, forKey: "animation")
        }
    }
    
    private func setupScene() {
        sceneView.scene = SCNScene()
        cameraNode.camera = camera
        camera.automaticallyAdjustsZRange = true
        cameraNode.worldPosition = SCNVector3(0, 10, 35)
        sceneView.scene?.rootNode.addChildNode(cameraNode)
        sceneView.pointOfView = cameraNode
        sceneView.autoenablesDefaultLighting = true
        sceneView.isUserInteractionEnabled = true
        let panGesture = UIPanGestureRecognizer(target: self, action: #selector(panCameraAction(_:)))
        sceneView.addGestureRecognizer(panGesture)
    }
    
    private func loadIslandScene() {
        robotNode = getRootNodeWithSceneName(sceneName: "ComponentsForLevels/MeeBot/Meebot")
        robotNode.worldPosition.z -= 10.0
        sceneView.scene?.rootNode.addChildNode(robotNode)
    }
    
    // MARK: Node
    fileprivate func getRootNodeWithSceneName(sceneName: String) -> SCNNode {
        var node = SCNNode()

        let path = "WorldResources.scnassets/_Scenes/" + sceneName
        guard let sceneURL = Bundle.main.url(forResource: path, withExtension: "scn"),
          let source = SCNSceneSource(url: sceneURL, options: nil) else {
              return node
        }
        do {
          let sourceScene = try source.scene()
          node = sourceScene.rootNode
        } catch {
          fatalError("Failed to Load Scene.\n \(error)")
        }

        return node.clone()
    }

    @objc func panCameraAction(_ recognizer: UIPanGestureRecognizer) {
        switch recognizer.state {
        case .began:
            break
        case .changed:
            SCNTransaction.begin()
            SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
            robotNode.eulerAngles.y += Float(recognizer.translation(in: recognizer.view!).x / 100)
            recognizer.setTranslation(CGPoint.zero, in: recognizer.view!)
            SCNTransaction.commit()
        case .ended:
            break
        default:
            break
        }
    }
    
    private func extractAnimation() -> CAAnimation? {
       guard let sceneURLs = Bundle.main.urls(forResourcesWithExtension: "scn", subdirectory: "") else { return nil }
       guard let sceneURL: URL = (sceneURLs.filter { $0.relativePath.contains("greeting") }.first) else { return nil }
       let t = SCNReferenceNode(url: sceneURL)
       t?.load()
        var animations = t?.animationKeys.compactMap { t?.animation(forKey: $0) } ?? []
        t?.enumerateChildNodes { child, _ in
            animations += child.animationKeys.compactMap {
              child.animation(forKey:$0)
          }
        }
        let animation = animations.first
       animation?.repeatCount = 0
       return animation
   }
}
