////
//  LiveViewTestApp
//
//  Created by George Michael on 23/01/2020
//

import UIKit

@objc(LetsCodeViewController)
class LetsCodeViewController: UIViewController {
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        loadInitialValues()
    }
    
    let codeStrings = [
        NSLocalizedString("cutsceneThirdScene", comment: ""),
        NSLocalizedString("cutsceneThirdScene_2", comment: "")
    ]
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        UIView.animate(withDuration: 0.5, delay: 0.5, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.yellowMinionImageView.alpha = 1
            self.yellowMinionImageView.transform = .identity
        })
        
        UIView.animate(withDuration: 0.5, delay: 0.75, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.textField.alpha = 1
            self.textField.transform = .identity
        })
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5, execute: {
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                      self.textField.alpha = 0
                      self.textField.transform =  CGAffineTransform(translationX: 0, y: -45)
            }, completion: { guard $0 else { return }
                self.textField.text = self.codeStrings[1]
                UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
                   self.textField.alpha = 1
                   self.textField.transform = .identity
                })
            })
        })
    }
    
    @IBOutlet weak var textField: UILabel!
    @IBOutlet weak var yellowMinionImageView: UIImageView!
    
    private func loadInitialValues() {
        textField.text = codeStrings[0]
        [yellowMinionImageView, textField].forEach { $0?.alpha = 0 }
        textField.transform = CGAffineTransform(translationX: 0, y: -45)
        yellowMinionImageView.transform = CGAffineTransform(translationX: 0, y: 45)
    }
}
