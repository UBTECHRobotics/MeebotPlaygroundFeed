//
//  EndViewController.swift
//  PlaygroundBook
//
//  Created by Dev on 15.05.2020.
//

import UIKit
import SceneKit
import AVFoundation

public class EndViewController: UIViewController {
    private let sceneView = SCNView()
    private let fadedView = UIView()
    private let titleLabel = UILabel()
    
    private var animationPlayer: SCNAnimationPlayer!
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()
    }
    
    public override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        delay(1) {
            self.setupAnimation()
        }
    }
    
    private func setupViews() {
        view.backgroundColor = #colorLiteral(red: 0, green: 0.6117647059, blue: 0.6509803922, alpha: 1)
        
        view.addSubview(sceneView)
        sceneView.scene = SCNScene(named: "WorldResources.scnassets/_Scenes/Level_5/Level_5.scn")
        sceneView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        sceneView.frame = view.bounds
        
        view.addSubview(fadedView)
        fadedView.alpha = 0
        fadedView.backgroundColor = #colorLiteral(red: 0, green: 0.6117647059, blue: 0.6509803922, alpha: 1)
        fadedView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        fadedView.frame = view.bounds
        
        fadedView.addSubview(titleLabel)
        titleLabel.text = NSLocalizedString("endingCongratulation", comment: "")
        titleLabel.numberOfLines = 0
        titleLabel.textAlignment = .center
        titleLabel.textColor = .white
        titleLabel.font = UIFont.systemFont(ofSize: 29, weight: .medium)
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        titleLabel.rightAnchor.constraint(equalTo: view.safeAreaLayoutGuide.rightAnchor, constant: -20).isActive = true
        titleLabel.leftAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leftAnchor, constant: 20).isActive = true
        
        animationPlayer = sceneView.pointOfView!.animationPlayer(forKey: sceneView.pointOfView!.animationKeys.first!)
        animationPlayer.paused = true
    }
    
    private func setupAnimation() {
        animationPlayer.play()
        UIView.animate(withDuration: 3, delay: 25, options: [.curveEaseIn], animations: {
            self.fadedView.alpha = 1
        })
    }
}

extension Double {
    func deg2rad() -> Double {
        return self * .pi / 180.0
    }
    
    func deg2rad() -> Float {
        return Float(self * .pi / 180.0)
    }
    
    func deg2rad() -> CGFloat {
        return CGFloat(self * .pi / 180.0)
    }
}

public func delay(_ delayInSeconds: Double, closure: @escaping () -> ()) {
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delayInSeconds * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: closure)
}
