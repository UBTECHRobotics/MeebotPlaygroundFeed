//
//  Rect.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import CoreGraphics

extension CGRect {
    public init(origin: Point, size: Size) {
        self.init(origin: origin.cgPoint, size: size.cgSize)
    }
}
