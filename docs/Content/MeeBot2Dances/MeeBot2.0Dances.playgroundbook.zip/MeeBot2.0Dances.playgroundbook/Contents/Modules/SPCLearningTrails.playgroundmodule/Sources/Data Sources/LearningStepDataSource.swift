//
//  LearningStepDataSource.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import UIKit
import SPCCore

public protocol LearningStepDataSource {
    var step: LearningStep { get }
    var blockCount: Int  { get }
    init(step: LearningStep)
    func styleForLearningStep(_ learningStep: LearningStep) -> LearningStepStyle?
    func styleForLearningBlock(_ learningBlock: LearningBlock) -> LearningBlockStyle?
    func textStyleForLearningBlock(_ learningBlock: LearningBlock) -> AttributedStringStyle?
    func viewForLearningBlock(_ learningBlock: LearningBlock) -> LearningBlockView?
}

extension LearningStepDataSource {
    public var blockCount: Int  {
        return step.blocks.count
    }
}
