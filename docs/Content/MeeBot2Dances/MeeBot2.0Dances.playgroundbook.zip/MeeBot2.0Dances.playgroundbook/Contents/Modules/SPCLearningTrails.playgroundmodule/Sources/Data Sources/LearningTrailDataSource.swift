//
//  LearningTrailDataSource.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import UIKit

public protocol LearningTrailDataSource {
    var trail: LearningTrail { get }
    var stepCount: Int  { get }
    var dataSourceProviderForStep: ((LearningStep) -> LearningStepDataSource) { get set }
    init(trail: LearningTrail)
    func viewControllerForStep(at index: Int) -> UIViewController?
    func index(of stepViewController: UIViewController) -> Int?
    func index(of step: LearningStep) -> Int?
    func refreshSteps()
}
