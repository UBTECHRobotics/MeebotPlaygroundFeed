//
//  CoordinateSystem.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import UIKit

// Coordinate system conversions
//
// TLO: top-left-origin coordinate system e.g. UIKit
//
//           (0, 0)
//              +------------+------------+
//              |            |            |
//              |            |            |
//              |            |            |
//              |            |            |
//              |            |            |
//              +------------+------------+
//              |            |            |
//              |            |            |
//              |            |            |
//              |            |            |
//              |            |            |
//              +------------+------------+
//                                  (bounds.width, bounds.height)
//
// CO:  center-origin coordinate system e.g. SPCComponents, SpriteKit
//
//                                (bounds.width / 2, bounds.height / 2)
//              +------------+------------+
//              |            |            |
//              |            |            |
//              |   (-, +)   |   (+, +)   |
//              |            |            |
//              |          (0, 0)         |
//              +------------+------------+
//              |            |            |
//              |            |            |
//              |   (-, -)   |   (+, -)   |
//              |            |            |
//              |            |            |
//              +------------+------------+
// (-bounds.width / 2, -bounds.height / 2)
//
// For example:
//
// A TLO rect (100, 200, 500, 400) within bounds of (1000, 1000) <==> CO position (-150, 100) and size (500, 400)
//
//           (0, 0)
//              +------------+------------+
//              |            |            |
//              | (100, 200) |            |
//              |  +-------+-|-----+      |
//              |  |         |     |      |
//              |  |      +  |     |      |
//              +------------+------------+
//              |  |         |     |      |
//              |  +---------|-----+      |
//              |            |            |
//              |            |            |
//              |            |            |
//              +------------+------------+
//                                  (bounds.width, bounds.height)

struct CoordinateSystem {
    
    // Returns the center-origin based position given a top-left-origin rect within the specified bounds.
    static func centerOriginPositionFor(topLeftOriginRect: CGRect, within bounds: CGSize) -> CGPoint {
        return CGPoint(x: (topLeftOriginRect.width / 2) + topLeftOriginRect.origin.x - (bounds.width / 2),
                       y: (bounds.height / 2) - (topLeftOriginRect.height / 2) - topLeftOriginRect.origin.y)
    }
    
    // Returns the top-left-origin rect given a center-origin based position and size within the specified bounds.
    static func topLeftOriginRectFor(centerOriginPosition: CGPoint, size: CGSize, within bounds: CGSize) -> CGRect {
        return CGRect(x: centerOriginPosition.x + (bounds.width / 2) - (size.width / 2),
                      y: (bounds.height / 2) - (size.height / 2) - centerOriginPosition.y,
                      width: size.width, height: size.height)
    }
    
    // Returns the top-left-origin center point given a center-origin based position and size within the specified bounds.
    static func topLeftOriginCenterFor(centerOriginPosition: CGPoint, size: CGSize, within bounds: CGSize) -> CGPoint {
        let frame = topLeftOriginRectFor(centerOriginPosition: centerOriginPosition, size: size, within: bounds)
        return CGPoint(x: frame.midX, y: frame.midY)
    }
}
