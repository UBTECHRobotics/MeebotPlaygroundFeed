//
//  OutputProperty.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation
import SPCCore

public class OutputProperty<T>: Output<T> where T: Codable {
    
    public var value: T {
        didSet {
            PBLog("OutputProperty: \(value) \(type(of: value))")
            notifyInputs(value)
        }
    }
    
    public init(_ intialValue: T) {
        value = intialValue
    }
}
