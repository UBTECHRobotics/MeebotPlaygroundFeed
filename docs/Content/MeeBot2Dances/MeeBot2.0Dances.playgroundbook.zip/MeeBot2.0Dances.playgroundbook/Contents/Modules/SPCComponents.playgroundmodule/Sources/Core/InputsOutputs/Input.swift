//
//  Input.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//

import Foundation

/// A type conforming to `EventReceiving` can receive event notifications of type `EventType`.
///
/// - localizationKey: EventReceiving
public protocol EventReceiving {
    associatedtype EventType
    var notifier: (EventType) -> Void { get }
}

/// An input can receive notification of events of `EventType`.
/// For example, an input of type `Input<Image>` can receive `Image` event notifications.
///
/// An `Output` can be connected to an `Input` of the same `EventType`, so that the input can receive event notifications from the output.
/// For example an `Output<Int>` can be connected to an `Input<Int>`, but not to an `Input<Double>`.
///
/// A component with an input of type `Input<EventType>` can receive notification of events of `EventType`.
///
/// - localizationKey: Input<EventType>
public class Input<EventType>: EventReceiving {
    
    /// The notifier function that’s called to notify the input of an event.
    /// If an output is connected to the input, this is the function the output will call to notify the input of an event.
    ///
    /// - localizationKey: Input<EventType>.notifier
    public var notifier: (EventType) -> Void = { _ in }
    
    /// Create an `Input` without a notifier function.
    ///
    /// - localizationKey: Input<EventType>()
    public init() { }
    
    /// Create an `Input`, giving it a notifier function.
    ///
    /// - localizationKey: Input<EventType>(_notifier:)
    public init(_ notifier: @escaping (EventType) -> Void) {
        self.notifier = notifier
    }
}
