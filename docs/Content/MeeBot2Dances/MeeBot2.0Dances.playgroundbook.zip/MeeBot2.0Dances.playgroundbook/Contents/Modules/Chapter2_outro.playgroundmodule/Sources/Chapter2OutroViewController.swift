////
//  LiveViewTestApp
//
//  Created by George Michael on 31/01/2020
//

import Foundation
import SceneKit
import PlaygroundSupport

@objc(Chapter2OutroViewController)
class Chapter2OutroViewController: UIViewController {
    
    @IBOutlet weak var sceneView: SCNView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var letsBeginButton: UIButton!
    @IBOutlet weak var letsBeginWidthConstraint: NSLayoutConstraint!
    
    
    let camera = SCNCamera()
    let cameraNode = SCNNode()
    var islandNode = SCNNode()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        titleLabel.text = NSLocalizedString("chapter2Page2Description", comment: "")
        titleLabel.alpha = 0
        titleLabel.transform = CGAffineTransform(translationX: 0, y: -45)
        sceneView.alpha = 0
        
        let letsBeginTitle = NSLocalizedString("letsBeginButton", comment: "")
        letsBeginButton.setTitle(letsBeginTitle, for: .normal)
        let letsBeginFont = UIFont.boldSystemFont(ofSize: 22)
        letsBeginWidthConstraint.constant = (letsBeginTitle as NSString).size(withAttributes: [.font : letsBeginFont]).width + 50
        letsBeginButton.layer.cornerRadius = 15
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setupScene()
        loadIslandScene()
        UIView.animate(withDuration: 0.5, delay: 0.5, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.titleLabel.alpha = 1
            self.titleLabel.transform = .identity
        })
        UIView.animate(withDuration: 0.5, delay: 1.0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0, options: .curveEaseIn, animations: {
            self.sceneView.alpha = 1
        })
    }

    private func setupScene() {
         sceneView.scene = SCNScene()
         cameraNode.camera = camera
         camera.automaticallyAdjustsZRange = true
         cameraNode.worldPosition = SCNVector3(0, 1.8, 3.35)
         sceneView.scene?.rootNode.addChildNode(cameraNode)
         sceneView.pointOfView = cameraNode
         sceneView.autoenablesDefaultLighting = true
         sceneView.isUserInteractionEnabled = true
         let panGesture = UIPanGestureRecognizer(target: self, action: #selector(panCameraAction(_:)))
         sceneView.addGestureRecognizer(panGesture)
    }
     
    private func loadIslandScene() {
        islandNode = getRootNodeWithSceneName(sceneName: "CommonMap/map_v10")
        let scaleFactor = 0.0075
        islandNode.scale = SCNVector3(scaleFactor,scaleFactor,scaleFactor)
        let targetNode = SCNLookAtConstraint(target: islandNode)
        targetNode.isGimbalLockEnabled = true
        sceneView.scene?.rootNode.addChildNode(islandNode)
        cameraNode.constraints = [targetNode]
    }
    
    // MARK: Node
    fileprivate func getRootNodeWithSceneName(sceneName: String) -> SCNNode {
        var node = SCNNode()
        
        let path = "WorldResources.scnassets/_Scenes/" + sceneName
        guard let sceneURL = Bundle.main.url(forResource: path, withExtension: "scn"),
            let source = SCNSceneSource(url: sceneURL, options: nil) else {
                return node
        }
        do {
            let sourceScene = try source.scene()
            node = sourceScene.rootNode
        }
        catch {
            fatalError("Failed to Load Scene.\n \(error)")
        }
        
        return node.clone()
    }

     @objc private func panCameraAction(_ recognizer: UIPanGestureRecognizer) {
        switch recognizer.state {
        case .began:
            break
        case .changed:
            SCNTransaction.begin()
            SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)
            islandNode.eulerAngles.y += Float(recognizer.translation(in: recognizer.view!).x / 100)
            recognizer.setTranslation(CGPoint.zero, in: recognizer.view!)
            SCNTransaction.commit()
        case .ended:
            break
        default:
            break
        }
    }
    
    @IBAction private func letsBeginAction(_ sender: Any) {
        PlaygroundPage.current.navigateTo(page: .next)
    }
}
