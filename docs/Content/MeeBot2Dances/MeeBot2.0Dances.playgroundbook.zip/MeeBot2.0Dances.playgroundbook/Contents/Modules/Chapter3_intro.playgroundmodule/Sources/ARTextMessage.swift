////
//  Book_Sources
//
//  Created by George Michael on 12/12/2019
//

import Foundation

public enum ARTextMessage {
    case pointCameraToTheRobot
    case pointCameraToFlatSurface
    case objectDetected
    case slowDown
    case moveBackAndForthToFindSurface
    case moveBackAndForthToFindRobot
    case noCamera
    case resuming
    case cantFindRobot
    
    public var text: String {
        switch self {
        case .pointCameraToTheRobot:
            return NSLocalizedString("Point your camera to the Meebot 2.0.", comment: "Point your camera to Meebot 2.0")
        case .pointCameraToFlatSurface:
            return NSLocalizedString("Point your camera to a flat surface.", comment: "Point your camera to a flat surface")
        case .objectDetected:
            return NSLocalizedString("Obect detected", comment: "Obect detected")
        case .slowDown:
            return NSLocalizedString("Try slowing down your movement, or run your code again.", comment: "Slow down movement string")
        case .moveBackAndForthToFindRobot:
            return NSLocalizedString("Move the iPad back and forth, while pointing towards Meebot 2.0", comment: "Flat Robot string")
        case .moveBackAndForthToFindSurface:
            return NSLocalizedString("Move the iPad back and forth, while pointing towards a flat surface", comment: "Flat surface string")
        case .noCamera:
            return  NSLocalizedString("Camera is not availabe. Please run your code again, and ensure Playgrounds is authorized to use the camera.", comment: "Camera is not available text")
        case .resuming:
            return NSLocalizedString("Resuming world tracking…", comment: "Restarted tracking text")
        case .cantFindRobot:
            return NSLocalizedString("Can't find the robot :(", comment: "Can't find the robot")
        }
    }
}
