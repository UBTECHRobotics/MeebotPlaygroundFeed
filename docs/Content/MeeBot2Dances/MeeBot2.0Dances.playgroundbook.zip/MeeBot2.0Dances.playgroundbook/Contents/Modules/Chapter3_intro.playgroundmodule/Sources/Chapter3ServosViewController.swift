////
//  LiveViewTestApp
//
//  Created by George Michael on 31/01/2020
//

import Foundation
import SceneKit
import ARKit
import PlaygroundSupport

@objc(Chapter3ServosViewController)
class Chapter3ServosViewController: UIViewController, ARSCNViewDelegate, ARSessionDelegate  {
    
    private var informationLabel: UILabel = UILabel(frame: CGRect(x:0, y:0, width:100, height:100))
    private var planeDetected = false
    private let loadingQueue = OperationQueue()
    
    // MARK: - Config Properties
    
    /// Model scale factor
    private let servoScaleFactor: Double = 0.9
    
    // node translations
    private let capTranslation: Float = 0.7
    private let bodyTranslation: Float = 0.25
    private let gear1Translation: Float = 0.57
    private let gear2Translation: Float = 0.45
    private let gear3Translation: Float = 0.61
    private let gear4Translation: Float = 0.64
    private let motorTranslation: Float = 0.03
    
    /// Gear rotation speed
    private let gearRotationSpeed: Double = 0.7
    
    private var servoNode = SCNNode()
    
    private var exploded = false
    private var isLessonCompleted = false
    
    @IBOutlet weak var arScnView: ARSCNView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        arScnView.delegate = self
        arScnView.session.delegate = self
        arScnView.autoenablesDefaultLighting = true
        arScnView.antialiasingMode = .multisampling4X
        setupInformationLabel()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startSession()
        addGestureToScene()
    }
    
    private func startSession() {
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal]
        arScnView.session.run(configuration, options: [])
    }
    
    private func stopSession() {
        let configuration = ARWorldTrackingConfiguration()
        arScnView.debugOptions = []
        arScnView.session.run(configuration, options: [])
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didAdd node: SCNNode, for anchor: ARAnchor) {
        guard !planeDetected else { return }
        planeDetected = true
        stopSession()
        DispatchQueue.main.async { [weak self] in
            self?.hideMessage()
        }
        displayServo(with: node)
    }
    
    public func session(_ session: ARSession, cameraDidChangeTrackingState camera: ARCamera) {
        DispatchQueue.main.async {
            switch camera.trackingState {
            case .limited(.excessiveMotion):
                self.show(message: ARTextMessage.slowDown.text)
            case .limited(.insufficientFeatures):
                self.show(message: ARTextMessage.moveBackAndForthToFindRobot.text )
            case .limited(.initializing):
                break
            case .notAvailable:
                self.show(message: ARTextMessage.noCamera.text )
            case .limited(.relocalizing):
                self.show(message: ARTextMessage.resuming.text)
            default:
                self.hideMessage()
            }
        }
    }
    
    func addGestureToScene() {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(sceneTapped))
        arScnView.addGestureRecognizer(tapGesture)
    }
    
    @objc private func sceneTapped(recognizer: UIGestureRecognizer) {
        let pos = recognizer.location(in: arScnView)
        let options: [SCNHitTestOption : Any] = [
                   SCNHitTestOption.rootNode: servoNode,
                   SCNHitTestOption.ignoreHiddenNodes: true]
        guard let _ = arScnView.hitTest(pos, options: options).first else { return }
        explode()
        if !isLessonCompleted {
            PlaygroundPage.current.assessmentStatus = .pass(message: NSLocalizedString("### Congratulations!\n\nYou now know what a servo motor is!\n\n[**Next Page**](@next)", comment:"Success message"))
            isLessonCompleted = true
        }
    }
    
    private func displayServo(with node: SCNNode?) {
          guard let node = node else { return }
          let mapScale = servoScaleFactor
          loadingQueue.addOperation {
              let path = "WorldResources.scnassets/_Scenes/ComponentsForLevels/Servo/servo-motor_0.6"
              guard
                 let sceneURL = Bundle.main.url(forResource: path, withExtension: "scn"),
                 let source = SCNSceneSource(url: sceneURL, options: nil) else {
                 return
              }
            let sourceScene = try! source.scene()
            self.servoNode = sourceScene.rootNode
            self.servoNode.scale = SCNVector3(mapScale,mapScale,mapScale)
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 1
            SCNTransaction.completionBlock =  {
                  node.addChildNode(self.servoNode)
                  SCNTransaction.begin()
                  SCNTransaction.animationDuration = 1
                  self.servoNode.opacity = 1
                  SCNTransaction.commit()
            }
            SCNTransaction.commit()
        }
    }
    
    private func explode() {
        let bodyNode = servoNode.childNode(withName: "body_0cm", recursively: true)
        let capNode = servoNode.childNode(withName: "cap__77_5cm", recursively: true)
        let gear2Node = servoNode.childNode(withName: "gear_2__45cm", recursively: true)
        let motorNode = servoNode.childNode(withName: "motor__27_5cm", recursively: true)
        let gear1Node = servoNode.childNode(withName: "gear_1__17_5cm", recursively: true)
        let gear3Node = servoNode.childNode(withName: "gear_3__32_5cm", recursively: true)
        let gear4Node = servoNode.childNode(withName: "gear_4__60cm", recursively: true)
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 1
        bodyNode?.position.y += exploded ? -bodyTranslation : bodyTranslation
        capNode?.position.y += exploded ? -capTranslation : capTranslation
        motorNode?.position.y += exploded ? -motorTranslation : motorTranslation
        gear2Node?.position.y += exploded ? -gear2Translation : gear2Translation
        gear1Node?.position.y += exploded ? -gear1Translation : gear1Translation
        gear3Node?.position.y += exploded ? -gear3Translation : gear3Translation
        gear4Node?.position.y += exploded ? -gear4Translation : gear4Translation
        SCNTransaction.animationTimingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        SCNTransaction.commit()
        if exploded {
            [gear1Node, gear2Node, gear3Node, gear4Node].forEach {
                $0?.removeAllActions()
            }
        } else {
            gear1Node?.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 2 * .pi, z: 0, duration: gearRotationSpeed)) )
            gear3Node?.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: -2 * .pi, z: 0, duration: gearRotationSpeed)) )
            gear4Node?.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: -2 * .pi, z: 0, duration: gearRotationSpeed)) )
            gear2Node?.runAction(SCNAction.repeatForever(SCNAction.rotateBy(x: 0, y: 2 * .pi, z: 0, duration: gearRotationSpeed)) )
        }
        exploded = !exploded
    }
    
    private func setupInformationLabel() {
         view.addSubview(informationLabel)
         informationLabel.translatesAutoresizingMaskIntoConstraints = false
         view.addConstraints( [
             NSLayoutConstraint(item: view!, attribute: .bottom, relatedBy: .equal, toItem: informationLabel, attribute: .bottom, multiplier: 1.0, constant: 120),
             NSLayoutConstraint(item: informationLabel, attribute: .centerX, relatedBy: .equal, toItem: view, attribute: .centerX, multiplier: 1.0, constant: 0),
             NSLayoutConstraint(item: informationLabel, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1.0, constant: 80),
             NSLayoutConstraint(item: informationLabel, attribute: .leftMargin, relatedBy: .greaterThanOrEqual, toItem: view, attribute: .leftMargin, multiplier: 1.0, constant: 0),
             NSLayoutConstraint(item: informationLabel, attribute: .rightMargin, relatedBy: .greaterThanOrEqual, toItem: view, attribute: .rightMargin, multiplier: 1.0, constant: 0)
         ])
         informationLabel.alpha = 0
         informationLabel.text = ""
         informationLabel.textColor = .white
         informationLabel.numberOfLines = 0
         informationLabel.transform = CGAffineTransform(translationX: 0, y: 50)
         informationLabel.textAlignment = .center
         informationLabel.font = UIFont.systemFont(ofSize: 25, weight: .bold)
         informationLabel.layer.shadowColor = UIColor.black.cgColor
         informationLabel.layer.shadowRadius = 3.0
         informationLabel.layer.shadowOpacity = 1.0
         informationLabel.layer.shadowOffset = CGSize(width: 0, height: 0)
         informationLabel.layer.masksToBounds = false
     }
    
    private func show(message: String ) {
        informationLabel.text = message
        UIView.animate(withDuration: 0.7,
                       delay: 0.0,
                       usingSpringWithDamping: 0.4,
                       initialSpringVelocity: 1.0,
                       options: .curveEaseOut, animations: {
            self.informationLabel.alpha = 1
            self.informationLabel.transform = .identity
        })
    }
    
    private func hideMessage(delay: Double = 0.0, completion: @escaping () -> Void = { } ) {
        UIView.animate(withDuration: 0.4, delay: delay, options: [.curveEaseOut], animations: {
           self.informationLabel.alpha = 0
           self.informationLabel.transform = CGAffineTransform(translationX: 0, y: 50)
        }, completion: { completed in
            completion()
            guard completed, !self.planeDetected else { return }
            self.show(message: ARTextMessage.pointCameraToFlatSurface.text)
       })
    }

}

