//#-hidden-code
//
//  Cutscene.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code

import PlaygroundSupport
import IntroCutscenes
import CutscenesBase
import UIKit

let vc = CutsceneContainerViewController(storyboardName: "Chapter1Cutscenes", plistName: "Cutscene", displaysPagingButtons: true)
vc.needsIncreasedScaling = true
vc.view.backgroundColor = UIColor.white
PlaygroundPage.current.liveView = vc
