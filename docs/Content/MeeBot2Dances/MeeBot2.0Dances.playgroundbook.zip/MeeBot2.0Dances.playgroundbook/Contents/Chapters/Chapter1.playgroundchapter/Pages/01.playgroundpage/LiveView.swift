/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
*/

import PlaygroundSupport
import MeebotModule

/// load the stage
let coordinate = Coordinate(column: 0, row: 0)
let facing: Direction = .north
let world = loadGridWorld(named: level1Path, coordinate: coordinate, facing: facing)
setUpLiveViewWith(world , .lesson1, type: .scn)
