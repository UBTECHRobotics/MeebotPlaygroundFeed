/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */

import PlaygroundSupport
import MeebotModule

let vc = SensorLessonViewController()
PlaygroundPage.current.liveView = vc
