/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */

import PlaygroundSupport
import MeebotModule

/// load the stage
let coordinate = Coordinate(column: 1, row: 0)
let world = loadGridWorld(named: level5Path, coordinate: coordinate)
setUpLiveViewWith(world, .lesson5, type: .ar)
