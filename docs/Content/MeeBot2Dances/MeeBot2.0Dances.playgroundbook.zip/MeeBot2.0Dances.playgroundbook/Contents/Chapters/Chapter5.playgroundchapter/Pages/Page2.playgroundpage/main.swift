//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
import SceneKit
import PlaygroundSupport
import MeebotModule
//#-end-hidden-code
//:#localized(key: "FirstProseBlock")
//#-hidden-code
func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    if successful ?? false {
        return .pass(message: NSLocalizedString("### Congratulations! You've successfully made your way\n\n[**Next Page**](@next)", comment:"Success message"))
    } else {
        return .fail(hints: ["You need to simplify the code for the blue path. Try again"], solution: nil)
    }
}

PlaygroundPage.current.needsIndefiniteExecution = true
let proxy = PlaygroundPage.current.liveView as! PlaygroundRemoteLiveViewProxy
commandManager = CommandManager()
proxy.delegate = commandManager
commandManager!.start()
assessmentManager = AssessmentManager(assessment)
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, if, moveForward(), turnLeft(), turnRight())
//#-editable-code
while !isFinalCell {
    if colorSensorDetects("blue") || colorSensorDetects("green") {
        moveForward()
    } else if colorSensorDetects("red") {
        turnLeft()
        if colorSensorDetects("blue") {
            moveForward()
        } else {
            turnRight()
            turnRight()
            moveForward()
        }
    } else {
        turnRight()
        if !colorSensorDetects("blue") {
            turnLeft()
            turnLeft()
        }
        moveForward()
    }
}
//#-end-editable-code
//#-hidden-code
commandManager?.finish()
//#-end-hidden-code

