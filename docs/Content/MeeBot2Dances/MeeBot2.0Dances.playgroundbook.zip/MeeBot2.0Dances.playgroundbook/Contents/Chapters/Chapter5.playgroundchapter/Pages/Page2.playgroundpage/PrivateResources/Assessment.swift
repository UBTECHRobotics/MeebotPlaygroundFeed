//
//  Assessment.swift
//  Playground
//
//  Created by WG on 2017/3/27.
//  Copyright © 2017年 WG. All rights reserved.
//

import Foundation
import PlaygroundSupport

let tip_missing = NSLocalizedString("Have you filled out all statements?", comment:"Success message")
let tip_fast_dance_error = NSLocalizedString("The rhythm for the first statement is incorrect ", comment:"Success message")
let tip_normal_dance_error = NSLocalizedString("The rhythm for the second statement is incorrect ", comment:"Success message")
let tip_slow_dance_error = NSLocalizedString("The rhythm for the last statement is incorrect ", comment:"Success message")
let success = NSLocalizedString("### Well done!\nYou know how to change the rhythm of a dance.\n\n[**Next Page**](@next)", comment:"Success message")

public func assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus {
    let checker = ContentsChecker(contents: PlaygroundPage.current.text)
    let conditionalNodes = checker.conditionalNodes
    guard !(conditionalNodes.contains { $0.body.isEmpty }) else {
        return .fail(hints: [tip_missing], solution: nil)
    }

    if let firstNode = conditionalNodes.first?.body.first as? CallNode, firstNode.identifier != "fastDance" {
        return .fail(hints: [tip_fast_dance_error], solution: nil)
    }
    if let secondNode = conditionalNodes[1].body.first as? CallNode, secondNode.identifier != "normalDance" {
        return .fail(hints: [tip_normal_dance_error], solution: nil)
    }
    if let thirdNode = conditionalNodes[2].body.first as? CallNode, thirdNode.identifier != "slowDance" {
        return .fail(hints: [tip_slow_dance_error], solution: nil)
    }
    return .pass(message: success)
}
