//#-hidden-code
//
//  Cutscene.swift
//  
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code

import PlaygroundSupport
import EndCutscene
import UIKit

let vc = EndViewController()
PlaygroundPage.current.liveView = vc
