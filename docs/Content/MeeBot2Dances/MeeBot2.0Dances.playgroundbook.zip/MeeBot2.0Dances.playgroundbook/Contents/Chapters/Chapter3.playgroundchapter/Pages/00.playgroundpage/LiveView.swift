/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */

import PlaygroundSupport
import MeebotModule

/// load the stage
let coordinate = Coordinate(column: 2, row: 2)
let world = loadGridWorld(named: level4Path, coordinate: coordinate)
setUpLiveViewWith(world, .lesson3, type: .ar)
