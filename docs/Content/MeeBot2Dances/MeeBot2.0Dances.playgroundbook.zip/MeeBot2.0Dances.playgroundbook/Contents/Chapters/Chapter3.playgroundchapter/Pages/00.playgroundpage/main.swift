//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
//#-hidden-code
import SceneKit
import PlaygroundSupport
//#-end-hidden-code
//:#localized(key: "FirstProseBlock")
//#-hidden-code
let success = NSLocalizedString("### Congratulations!\n\n[**Next Page**](@next)", comment:"Success message")
let number_tip = NSLocalizedString("Good, keep practicing. Use at least 6 different moves.", comment:"Number message")

func lesson2Assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    let actions = commands.flatMap{$0.action == .start || $0.action == .finish ? nil : $0.action}
    
    let isSuccess = !actions.isEmpty && actions.count >= 6 && actions.contains(.moveLeftArm) && actions.contains(.moveRightArm) && actions.contains(.moveLeftLeg) && actions.contains(.moveRightLeg) && actions.contains(.moveLeftFoot) && actions.contains(.moveRightFoot)

    return isSuccess ? .pass(message: success) : .fail(hints: [number_tip], solution: nil)
}

PlaygroundPage.current.needsIndefiniteExecution = true
let proxy = PlaygroundPage.current.liveView as! PlaygroundRemoteLiveViewProxy
commandManager = CommandManager()
proxy.delegate = commandManager
commandManager!.start()
assessmentManager = AssessmentManager(lesson2Assessment)
//#-end-hidden-code
func myDanceRoutine() {
    //#-code-completion(everything, hide)
    //#-code-completion(identifier, show, moveLeftArm(angle:), moveRightArm(angle:), moveLeftLeg(angle:), moveRightLeg(angle:), moveLeftFoot(angle:), moveRightFoot(angle:))
    for i in 1 ... /*#-editable-code*/<#T##number##Int#>/*#-end-editable-code*/ {
        //#-editable-code Tap to enter code
        
        //#-end-editable-code
        //#-hidden-code
        standBy()
        //#-end-hidden-code
    }
}
myDanceRoutine()
//#-hidden-code
commandManager?.finish()
//#-end-hidden-code
