/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 */

import PlaygroundSupport
import UIKit
import Chapter3_intro

let storyboard = UIStoryboard(name: "Chapter3Servos", bundle: nil)
let vc = storyboard.instantiateViewController(withIdentifier: "Chapter3Servos")
PlaygroundPage.current.liveView = vc
