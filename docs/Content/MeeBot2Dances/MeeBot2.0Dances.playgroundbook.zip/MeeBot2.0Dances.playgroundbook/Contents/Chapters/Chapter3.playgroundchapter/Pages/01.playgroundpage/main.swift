//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
//#-end-hidden-code
//#-hidden-code
import PlaygroundSupport
//#-end-hidden-code
//:#localized(key: "FirstProseBlock")
//#-code-completion(everything, hide)
