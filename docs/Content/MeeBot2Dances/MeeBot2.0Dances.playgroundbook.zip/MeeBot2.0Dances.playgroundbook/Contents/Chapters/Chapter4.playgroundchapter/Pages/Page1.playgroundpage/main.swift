//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
 */
import SceneKit
import PlaygroundSupport
import MeebotModule
//#-end-hidden-code
//:#localized(key: "FirstProseBlock")
//#-hidden-code
let empty = NSLocalizedString("### You are so close. Try typing \"fastDance()\", \"slowDance()\", \"normalDance()\" on the code editor.", comment:"")
let success = NSLocalizedString("### Congratulations!\n\n[**Next Page**](@next)", comment:"Success message")

public func lesson4Assessment(_ commands:[Command], successful:Bool?)-> PlaygroundPage.AssessmentStatus {
    let actions = commands.flatMap{$0.action == .start || $0.action == .finish ? nil : $0.action}
    return actions.count >= 1 ? .pass(message: success) : .fail(hints: [empty], solution: nil)
}

PlaygroundPage.current.needsIndefiniteExecution = true
let proxy = PlaygroundPage.current.liveView as! PlaygroundRemoteLiveViewProxy
commandManager = CommandManager()
proxy.delegate = commandManager
commandManager!.start()
assessmentManager = AssessmentManager(lesson4Assessment)
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, slowDance(), fastDance(), normalDance())
if BPMofCurrentMusic == 120 {
    //#-editable-code
    //#-end-editable-code
} else if BPMofCurrentMusic == 60 {
    //#-editable-code
    //#-end-editable-code
} else {
    //#-editable-code
    //#-end-editable-code
}
//#-hidden-code
commandManager?.finish()
//#-end-hidden-code

