//#-hidden-code
//
//  Cutscene.swift
//
//  Copyright © 2016-2019 Apple Inc. All rights reserved.
//
//#-end-hidden-code

import PlaygroundSupport
import IntroCutscenes
import Chapter2_outro
import CutscenesBase
import UIKit

let vc = CutsceneContainerViewController(storyboardName: "Chapter2Cutscenes", plistName: "Cutscene", displaysPagingButtons: false)
vc.needsIncreasedScaling = true
PlaygroundPage.current.liveView = vc
