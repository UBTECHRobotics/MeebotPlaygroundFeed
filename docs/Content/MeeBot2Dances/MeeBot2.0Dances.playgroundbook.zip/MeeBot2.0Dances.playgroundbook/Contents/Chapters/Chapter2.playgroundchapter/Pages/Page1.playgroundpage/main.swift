//#-hidden-code
/*
 Copyright (C) 2016 UBTech Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information.
 
 This is a second example page.
*/
import Foundation
import PlaygroundSupport
//#-end-hidden-code
//:#localized(key: "FirstProseBlock")
//#-hidden-code
let success = NSLocalizedString("### Well done.\nYou know how to use basic dance commands.\n\n[**Next Page**](@next)", comment:"Success message")
let number_tip = NSLocalizedString("Good, keep practicing. Use at least 4 moves.", comment:"Number message")
let type_tip = NSLocalizedString("Nice, change just a little bit. You need to move forward, then right, then backward, then left", comment:"Type message")
let empty_tip = NSLocalizedString("You need to enter basic move commands to make MeeBot 2.0 dance. Use the 4 dance moves in this order: forward, right, backward, left", comment:"Empty message")

func lesson2Assessment(_ commands:[Command], successful:Bool?)->PlaygroundPage.AssessmentStatus{
    let actions = commands.flatMap{$0.action == .start || $0.action == .finish ? nil : $0.action}
    if actions.isEmpty {
        return .fail(hints: [empty_tip], solution: nil)
    }
    if actions.count < 4 {
        return .fail(hints: [number_tip], solution: nil)
    }
    
    if actions[0] != .moveForward {
        return .fail(hints: [type_tip], solution: nil)
    }
    
    if actions[1] != .moveToRight {
        return .fail(hints: [type_tip], solution: nil)
    }
    
    if actions[2] != .moveBackward {
        return .fail(hints: [type_tip], solution: nil)
    }
    
    if actions[3] != .moveToLeft {
        return .fail(hints: [type_tip], solution: nil)
    }

    return .pass(message: success)
}


PlaygroundPage.current.needsIndefiniteExecution = true
let proxy = PlaygroundPage.current.liveView as! PlaygroundRemoteLiveViewProxy
commandManager = CommandManager()
proxy.delegate = commandManager
commandManager!.start()
assessmentManager = AssessmentManager(lesson2Assessment)
//#-end-hidden-code
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, moveToLeft(), moveToRight(), moveForward(), moveBackward())
//#-editable-code Tap to enter code
//#-end-editable-code
//#-hidden-code
commandManager?.finish()
//#-end-hidden-code
